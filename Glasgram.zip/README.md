# Glasgram

**A native Android Telegram client concept with a custom Liquid Glass interface.**

Glasgram is built with Kotlin, Jetpack Compose, and the official TDLib client library. It is an independent third-party client project, not an official Telegram app.

## Project status (v0.2.0)

**Implemented in source (not yet verified on a physical device):**
- [x] Liquid-glass UI: translucent glass cards, specular rims, drifting light orbs, floating glass tab bar
- [x] TDLib gateway and basic authorization states for phone, code and two-step password
- [x] Chat list: live updates, last-message preview, unread badges, pinned/muted, local search and basic type filters
- [x] Long-press chat actions: pin, mute, mark as read
- [x] Conversation basics: text send, reply, edit, delete, copy, date separators and history paging
- [x] Glasgram client settings: Ghost Mode, Always Offline, deleted-message guard, edit history, appearance controls and haptics
- [x] TDLib database key wrapped with AES-256-GCM using Android Keystore
- [x] Scheduled official Telegram Android/TDLib upstream change watcher and report issue workflow

**Still incomplete:** media upload/download and playback, stickers/reactions/polls/forwarding/scheduling, full folders and search, groups/channels administration, contacts, calls, stories, bots/Mini Apps, push notifications, Secret Chat support, multiple accounts, and most third-party client features. The TDLib JNI runtime and all login/message flows still require build and device verification.

## Build

Requirements: Android Studio (current stable), JDK 17, Android SDK 36, and Gradle 8.11.1 or compatible.

```bash
gradle --no-daemon assembleDebug
```

This source archive does not currently include the Gradle wrapper JAR. CI installs Gradle 8.11.1 explicitly. The APK is not considered verified until CI and a physical-device smoke test pass.

The debug APK is normally generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Telegram API setup

1. Create your own application credentials at https://my.telegram.org.
2. Supply `TELEGRAM_API_ID` and `TELEGRAM_API_HASH` as local Gradle properties or environment variables; never commit real credentials.
3. Follow [docs/TDLIB_SETUP.md](docs/TDLIB_SETUP.md) to package the matching TDLib Java/JNI runtime for Android.
4. Test authorization and messaging before enabling any feature flag.

The API credentials identify the client application; they are not a substitute for a user's login code or password. Do not collect login codes outside TDLib's authorization flow.

## Architecture

- `feature/`: Compose screens and UI state
- `data/telegram/`: TDLib adapter and update stream
- `core/design/`: reusable glass surfaces, colors, and typography
- `docs/`: integration and release guidance

## Security

- Do not commit API hashes, user sessions, TDLib database files, or signing keys.
- The TDLib database key is generated locally and wrapped by an AES-256-GCM key in Android Keystore. Do not reset its encrypted preference while retaining the TDLib database.
- Cloud chats and Secret Chats have different security and synchronization properties.
- Follow Telegram API terms and all applicable licenses.

## License

The project's own code is currently marked as **MIT** in `LICENSE`. Third-party dependencies and TDLib remain subject to their own licenses. This does not relicense Telegram's code or branding.


## Automatic Telegram upstream updates

Glasgram includes a scheduled GitHub Actions watcher for the official Telegram Android and TDLib repositories. It generates an upstream change report and opens/updates a review issue. See [docs/AUTO_UPDATE_ENGINE.md](docs/AUTO_UPDATE_ENGINE.md).

The watcher intentionally does not blindly merge upstream code or publish APKs. Telegram Android and TDLib releases can be independent, and the Java TDLib API must match its native JNI binaries and packaged ABIs. Review, integration, tests and release approval remain required.

## Verified scope and remaining work

See [docs/IMPLEMENTATION_STATUS.md](docs/IMPLEMENTATION_STATUS.md) for the phase-by-phase implementation matrix, what this source revision adds, what remains incomplete, and what has not been verified.
