package com.glasgram.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** A SharedPreferences-backed value that is also observable by Compose. */
class Pref<T : Any>(
    private val sp: SharedPreferences,
    private val key: String,
    default: T
) : ReadWriteProperty<Any?, T> {
    private val state = mutableStateOf(read(default))

    @Suppress("UNCHECKED_CAST")
    private fun read(d: T): T = when (d) {
        is Boolean -> sp.getBoolean(key, d) as T
        is Float -> sp.getFloat(key, d) as T
        is Int -> sp.getInt(key, d) as T
        else -> d
    }

    override fun getValue(thisRef: Any?, property: KProperty<*>): T = state.value

    override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        state.value = value
        val editor = sp.edit()
        when (value) {
            is Boolean -> editor.putBoolean(key, value)
            is Float -> editor.putFloat(key, value)
            is Int -> editor.putInt(key, value)
            else -> Unit
        }
        editor.apply()
    }
}

/** All "Glasgram Settings": mod features Telegram itself does not offer. */
class GlasSettings(context: Context) {
    private val sp = context.getSharedPreferences("glasgram_settings", Context.MODE_PRIVATE)

    // Hidden chats: stored locally and restored across app restarts.
    private val hiddenState = mutableStateOf(
        sp.getStringSet("hiddenChatIds", emptySet<String>())?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet<Long>()
    )
    val hiddenChatIds: Set<Long> get() = hiddenState.value

    fun isChatHidden(chatId: Long): Boolean = chatId in hiddenState.value

    fun setChatHidden(chatId: Long, hidden: Boolean) {
        val next = hiddenState.value.toMutableSet()
        if (hidden) next.add(chatId) else next.remove(chatId)
        hiddenState.value = next
        sp.edit().putStringSet("hiddenChatIds", next.map { it.toString() }.toSet()).apply()
    }

    // Custom local chat folders. Telegram chat data remains untouched.
    private val folderNamesState = mutableStateOf(sp.getStringSet("customFolderNames", emptySet())?.toList()?.sorted() ?: emptyList())
    val customFolderNames: List<String> get() = folderNamesState.value

    fun createFolder(name: String): Boolean {
        val clean = name.trim().take(24)
        if (clean.isBlank() || folderNamesState.value.any { it.equals(clean, ignoreCase = true) }) return false
        val next = (folderNamesState.value + clean).sortedBy { it.lowercase() }
        folderNamesState.value = next
        sp.edit().putStringSet("customFolderNames", next.toSet()).apply()
        return true
    }

    fun folderForChat(chatId: Long): String? = sp.getString("chatFolder_$chatId", null)

    fun assignChatToFolder(chatId: Long, folder: String?) {
        val editor = sp.edit()
        if (folder == null) editor.remove("chatFolder_$chatId") else editor.putString("chatFolder_$chatId", folder)
        editor.apply()
    }

    fun deleteFolder(folder: String) {
        folderNamesState.value = folderNamesState.value.filterNot { it == folder }
        sp.edit().putStringSet("customFolderNames", folderNamesState.value.toSet()).apply()
        sp.all.keys.filter { it.startsWith("chatFolder_") && sp.getString(it, null) == folder }
            .forEach { sp.edit().remove(it).apply() }
    }

    // Ghost & privacy
    var ghostRead by Pref(sp, "ghostRead", false)
    var alwaysOffline by Pref(sp, "alwaysOffline", false)

    // Notifications
    var notifications by Pref(sp, "notifications", true)
    var notifPreview by Pref(sp, "notifPreview", true)
    var keepAlive by Pref(sp, "keepAlive", false)

    // Security & updates
    var appLock by Pref(sp, "appLock", false)
    var secureScreen by Pref(sp, "secureScreen", false)
    var checkUpdates by Pref(sp, "checkUpdates", true)

    // Message guard
    var keepDeleted by Pref(sp, "keepDeleted", true)
    var keepEdits by Pref(sp, "keepEdits", true)

    // Appearance
    var accentIndex by Pref(sp, "accentIndex", 0)
    var glassIntensity by Pref(sp, "glassIntensity", 0.55f)
    var bubbleRadius by Pref(sp, "bubbleRadius", 22f)
    var textScale by Pref(sp, "textScale", 1f)
    var animatedBackground by Pref(sp, "animatedBackground", true)

    // Interface
    var compactList by Pref(sp, "compactList", false)
    var use24h by Pref(sp, "use24h", true)
    var showIds by Pref(sp, "showIds", false)
    var doubleTapReply by Pref(sp, "doubleTapReply", true)
    var haptics by Pref(sp, "haptics", true)

    // Turbo-style interface preferences
    var showCategoryBar by Pref(sp, "showCategoryBar", true)
    var showCameraShortcut by Pref(sp, "showCameraShortcut", true)
    var showFloatingCompose by Pref(sp, "showFloatingCompose", true)
    var largeAvatars by Pref(sp, "largeAvatars", false)
    var showOnlineStatus by Pref(sp, "showOnlineStatus", true)
    var saveToGallery by Pref(sp, "saveToGallery", false)
    var toastNotifications by Pref(sp, "toastNotifications", true)
    var confirmBeforeDelete by Pref(sp, "confirmBeforeDelete", true)
    var autoPlayVideos by Pref(sp, "autoPlayVideos", false)
    var reduceMotion by Pref(sp, "reduceMotion", false)
}
