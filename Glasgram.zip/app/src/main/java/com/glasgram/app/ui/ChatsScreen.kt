package com.glasgram.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.consume
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasgram.app.data.ChatInfo
import com.glasgram.app.data.ChatKind
import com.glasgram.app.data.TgRepository

private val FilterNames = listOf("All", "Unread", "Personal", "Groups", "Channels", "Hidden", "Archived")

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatsScreen(repo: TgRepository, onOpen: (Long) -> Unit) {
    val s = LocalGlas.current
    val a = accent()
    val haptic = rememberHaptic()
    var query by remember { mutableStateOf("") }
    var searchMode by remember { mutableIntStateOf(0) } // 0 chats, 1 loaded, 2 Telegram server
    var filter by remember { mutableIntStateOf(0) }
    var menuChat by remember { mutableStateOf<ChatInfo?>(null) }
    var showNewFolder by remember { mutableStateOf(false) }
    var showMuteOptions by remember { mutableStateOf(false) }
    var showDeleteFolder by remember { mutableStateOf(false) }
    var folderToDelete by remember { mutableStateOf<String?>(null) }
    var muteTarget by remember { mutableStateOf<ChatInfo?>(null) }
    var newFolderName by remember { mutableStateOf("") }

    val all = if (filter == 6) repo.sortedArchivedChats() else repo.sortedChats()
    val folderNames = s.customFolderNames
    val hiddenIds = s.hiddenChatIds
    val hiddenCount = all.count { it.id in hiddenIds }
    val unreadChats = all.count { it.id !in hiddenIds && (it.unread > 0 || it.markedUnread) }
    val shown = all.filter { c ->
        val isHidden = c.id in hiddenIds
        val okFilter = when (filter) {
            1 -> !isHidden && (c.unread > 0 || c.markedUnread)
            2 -> !isHidden && (c.kind == ChatKind.Private || c.kind == ChatKind.Secret)
            3 -> !isHidden && c.kind == ChatKind.Group
            4 -> !isHidden && c.kind == ChatKind.Channel
            5 -> isHidden
            6 -> true
            in 7..Int.MAX_VALUE -> !isHidden && s.folderForChat(c.id) == folderNames.getOrNull(filter - 7)
            else -> !isHidden
        }
        okFilter && (searchMode == 0) && (query.isBlank() || c.title.contains(query.trim(), ignoreCase = true) || c.lastText.contains(query.trim(), ignoreCase = true))
    }
    LaunchedEffect(query, searchMode) {
        if (searchMode == 2 && query.isNotBlank()) {
            kotlinx.coroutines.delay(400)
            repo.searchGlobalMessages(query)
        }
    }
    val messageResults = if (searchMode == 1 && query.isNotBlank()) {
        repo.messages.entries.flatMap { (chatId, items) ->
            val chatInfo = repo.chats[chatId]
            items.filter { it.text.contains(query.trim(), ignoreCase = true) }
                .map { msg -> Triple(chatId, chatInfo?.title ?: "Chat", msg) }
        }.sortedByDescending { it.third.date }.take(100)
    } else emptyList()

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // Large title + quick mod toggles
            Row(
                Modifier.fillMaxWidth().padding(start = 22.dp, end = 16.dp, top = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("GLASGRAM", color = a, fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                    Text("Chats", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                }
                GlassCircleButton(active = s.ghostRead, onClick = { s.ghostRead = !s.ghostRead; haptic() }) {
                    Text("👻", fontSize = 18.sp)
                }
                Spacer(Modifier.width(8.dp))
                GlassCircleButton(active = s.alwaysOffline, onClick = { s.alwaysOffline = !s.alwaysOffline; haptic() }) {
                    Text("🌙", fontSize = 18.sp)
                }
            }

            // Search
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(18.dp))
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Search, contentDescription = null, tint = Muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Search chats", color = Muted, fontSize = 16.sp)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                        cursorBrush = SolidColor(a),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (query.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Close, contentDescription = "Clear", tint = Muted,
                        modifier = Modifier.size(20.dp).clickable { query = "" }
                    )
                }
            }

            if (query.isNotBlank()) {
                Spacer(Modifier.height(9.dp))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Chats", "Loaded", "Telegram search").forEachIndexed { index, label ->
                        Text(
                            label,
                            color = if (searchMode == index) Color.White else Muted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .glass(CircleShape, boost = if (searchMode == index) 1.8f else 0.7f, tint = if (searchMode == index) a else Color.White)
                                .clickable { searchMode = index; haptic() }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            // Folder chips
            if (s.showCategoryBar && query.isBlank()) {
                Spacer(Modifier.height(10.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(FilterNames + folderNames + listOf("＋ New")) { i, name ->
                        val selected = i == filter
                        val label = when (i) {
                            1 -> if (unreadChats > 0) "$name · $unreadChats" else name
                            5 -> if (hiddenCount > 0) "$name · $hiddenCount" else name
                            else -> name
                        }
                        Text(
                            label,
                            color = if (selected) Color.White else Muted,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .glass(CircleShape, boost = if (selected) 2.2f else 0.8f, tint = if (selected) a else Color.White)
                                .combinedClickable(
                                    onClick = {
                                        if (i == 7 + folderNames.size) { showNewFolder = true; newFolderName = "" }
                                        else filter = i
                                        haptic()
                                    },
                                    onLongClick = {
                                        if (i in 7 until 7 + folderNames.size) {
                                            folderToDelete = folderNames[i - 7]
                                            showDeleteFolder = true
                                            haptic()
                                        }
                                    }
                                )
                                .padding(horizontal = 16.dp, vertical = 9.dp)
                        )
                    }
                }
            }

            if (searchMode == 2 && query.isNotBlank()) {
                val serverResults = repo.globalSearchResults.values.flatten().sortedByDescending { it.date }
                if (repo.globalSearchBusy) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = a) }
                } else if (serverResults.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No Telegram search results", color = Muted, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(serverResults, key = { "server:${it.chatId}:${it.id}" }) { msg ->
                            val title = repo.chats[msg.chatId]?.title ?: "Telegram chat"
                            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).clickable {
                                onOpen(msg.chatId)
                                repo.openMessageResult(msg.chatId, msg.id)
                            }.padding(14.dp)) {
                                Text(title, color = a, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(msg.text, color = Color.White, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                Text(formatListTime(msg.date, s.use24h), color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            } else if (searchMode == 1 && query.isNotBlank()) {
                if (messageResults.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("No loaded messages found", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(5.dp))
                            Text("Search covers messages currently loaded in Glasgram.", color = Muted, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messageResults, key = { "${it.first}:${it.third.id}" }) { result ->
                            val (chatId, title, msg) = result
                            Column(
                                Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp))
                                    .clickable { onOpen(chatId); repo.openMessageResult(chatId, msg.id) }
                                    .padding(14.dp)
                            ) {
                                Text(title, color = a, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(5.dp))
                                Text(msg.text, color = Color.White, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                Text(formatListTime(msg.date, s.use24h), color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            } else if (all.isEmpty()) {
                Column(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = a)
                    Spacer(Modifier.height(14.dp))
                    Text("Syncing your chats…", color = Muted)
                }
            } else if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            when (filter) {
                                1 -> "All caught up"
                                5 -> "No hidden chats"
                                6 -> "Archive is empty"
                                else -> "Nothing here"
                            },
                            color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(5.dp))
                        Text(
                            when (filter) {
                                1 -> "Unread conversations will appear here"
                                5 -> "Long-press a chat and choose Hide chat"
                                6 -> "Archived conversations will appear here"
                                else -> "Try another folder or search"
                            },
                            color = Muted, fontSize = 13.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 130.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(shown, key = { it.id }) { c ->
                        ChatRow(
                            c = c,
                            compact = s.compactList,
                            showIds = s.showIds,
                            h24 = s.use24h,
                            photoPath = repo.filePath(c.photoFileId),
                            onClick = { onOpen(c.id) },
                            onLongClick = { haptic(); menuChat = c },
                            onSwipeLeft = {
                                if (c.id in repo.archivedChatIds) repo.unarchiveChat(c.id) else repo.archiveChat(c.id)
                            },
                            onSwipeRight = {
                                repo.setMuteFor(c, if (c.muted) 0 else 366 * 24 * 3600)
                            }
                        )
                    }
                }
            }
        }

        val menu = menuChat
        if (menu != null) {
            GlassSheet(title = menu.title, onDismiss = { menuChat = null }) {
                SheetAction("📌", if (menu.pinned) "Unpin" else "Pin to top") { repo.togglePin(menu); menuChat = null }
                SheetAction(if (menu.id in repo.archivedChatIds) "📤" else "📥",
                    if (menu.id in repo.archivedChatIds) "Unarchive chat" else "Archive chat") {
                    if (menu.id in repo.archivedChatIds) repo.unarchiveChat(menu.id) else repo.archiveChat(menu.id)
                    menuChat = null
                }
                SheetAction(if (menu.muted) "🔔" else "🔇", if (menu.muted) "Unmute" else "Mute options") {
                    if (menu.muted) { repo.setMuteFor(menu, 0); menuChat = null }
                    else { muteTarget = menu; showMuteOptions = true }
                }
                SheetAction("✓", if (menu.markedUnread) "Mark as read" else "Mark as unread") {
                    if (menu.unread > 0 || menu.markedUnread) repo.markReadNow(menu.id)
                    else repo.toggleMarkedUnread(menu)
                    menuChat = null
                }
                SheetAction("🙈", if (repo.settings.isChatHidden(menu.id)) "Unhide chat" else "Hide chat") {
                    repo.settings.setChatHidden(menu.id, !repo.settings.isChatHidden(menu.id))
                    menuChat = null
                }
                if (s.customFolderNames.isNotEmpty()) {
                    Text("MOVE TO FOLDER", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 18.dp, top = 10.dp, bottom = 2.dp))
                    s.customFolderNames.forEach { folder ->
                        SheetAction("▦", if (s.folderForChat(menu.id) == folder) "$folder ✓" else folder) {
                            s.assignChatToFolder(menu.id, if (s.folderForChat(menu.id) == folder) null else folder)
                            menuChat = null
                        }
                    }
                    if (s.folderForChat(menu.id) != null) {
                        SheetAction("↩", "Remove from folder") { s.assignChatToFolder(menu.id, null); menuChat = null }
                    }
                }
            }
        }
        if (showMuteOptions) {
            val target = muteTarget
            AlertDialog(
                onDismissRequest = { showMuteOptions = false; muteTarget = null },
                title = { Text("Mute notifications") },
                text = {
                    Column {
                        listOf("1 hour" to 3600, "8 hours" to 28800, "2 days" to 172800, "Forever" to (366 * 24 * 3600)).forEach { (label, seconds) ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    target?.let { repo.setMuteFor(it, seconds) }
                                    showMuteOptions = false; muteTarget = null; menuChat = null
                                }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(label, modifier = Modifier.weight(1f), color = Color.White)
                                RadioButton(selected = false, onClick = {
                                    target?.let { repo.setMuteFor(it, seconds) }
                                    showMuteOptions = false; muteTarget = null; menuChat = null
                                })
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showMuteOptions = false; muteTarget = null }) { Text("Cancel") } }
            )
        }
        if (showDeleteFolder) {
            val folder = folderToDelete
            AlertDialog(
                onDismissRequest = { showDeleteFolder = false; folderToDelete = null },
                title = { Text("Delete folder?") },
                text = { Text("Delete ${folder ?: "this folder"}? Chats will remain in your main list; they will not be deleted.") },
                confirmButton = {
                    TextButton(onClick = {
                        folder?.let { s.deleteFolder(it) }
                        if (filter >= 7) filter = 0
                        showDeleteFolder = false
                        folderToDelete = null
                    }) { Text("Delete") }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteFolder = false; folderToDelete = null }) { Text("Cancel") }
                }
            )
        }
        if (showNewFolder) {
            AlertDialog(
                onDismissRequest = { showNewFolder = false },
                title = { Text("Create chat folder") },
                text = {
                    OutlinedTextField(value = newFolderName, onValueChange = { newFolderName = it.take(24) },
                        singleLine = true, label = { Text("Folder name") })
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (s.createFolder(newFolderName)) showNewFolder = false
                    }) { Text("Create") }
                },
                dismissButton = { TextButton(onClick = { showNewFolder = false }) { Text("Cancel") } }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(
    c: ChatInfo,
    compact: Boolean,
    showIds: Boolean,
    h24: Boolean,
    photoPath: String?,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onSwipeLeft: () -> Unit,
    onSwipeRight: () -> Unit
) {
    val a = accent()
    val unread = c.unread > 0 || c.markedUnread
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(24.dp), boost = if (unread) 1.35f else 1f)
            .pointerInput(c.id) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onHorizontalDrag = { change, amount ->
                        drag += amount
                        change.consume()
                    },
                    onDragEnd = {
                        when {
                            drag < -120f -> onSwipeLeft()
                            drag > 120f -> onSwipeRight()
                        }
                    }
                )
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 14.dp, vertical = if (compact) 9.dp else 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .width(3.dp)
                .height(if (compact) 42.dp else 52.dp)
                .clip(CircleShape)
                .background(if (unread) a else Color.Transparent)
        )
        Spacer(Modifier.width(9.dp))
        Avatar(c.title, c.id, if (compact) 44.dp else 54.dp, photoPath)
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    c.title, color = Color.White, fontSize = 16.5.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Text(
                    when (c.kind) {
                        ChatKind.Private -> "DM"
                        ChatKind.Secret -> "SECRET"
                        ChatKind.Group -> "GROUP"
                        ChatKind.Channel -> "CHANNEL"
                    },
                    color = Muted.copy(alpha = 0.82f),
                    fontSize = 8.sp,
                    letterSpacing = 0.7.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(5.dp))
                        .background(Color.White.copy(alpha = 0.055f))
                        .padding(horizontal = 5.dp, vertical = 3.dp)
                )
                if (c.muted) Text(" 🔇", fontSize = 10.sp)
                if (c.pinned) Text(" 📌", fontSize = 10.sp)
                Spacer(Modifier.width(7.dp))
                Text(
                    formatListTime(c.lastDate, h24),
                    color = if (unread && !c.muted) a else Muted, fontSize = 12.sp
                )
            }
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                val preview = (if (c.lastOutgoing) "You: " else "") + c.lastText.replace('\n', ' ')
                Text(
                    preview.ifBlank { "No messages yet" },
                    color = Muted, fontSize = 14.sp,
                    maxLines = if (compact) 1 else 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (unread) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .defaultMinSize(minWidth = 22.dp, minHeight = 22.dp)
                            .clip(CircleShape)
                            .background(if (c.muted) Color(0xFF5B6479) else a)
                            .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (c.unread > 99) "99+" else if (c.unread > 0) c.unread.toString() else "•",
                            color = if (c.muted) Color.White else Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            if (showIds) {
                Text("ID ${c.id}", color = Muted.copy(alpha = 0.7f), fontSize = 10.sp)
            }
        }
    }
}
