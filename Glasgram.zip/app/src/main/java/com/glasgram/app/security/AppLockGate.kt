package com.glasgram.app.security

import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/**
 * Biometric / device-PIN app lock. Wrap your root UI:
 *     AppLockGate(enabled = settings.appLock) { YourApp() }
 * MainActivity must extend FragmentActivity (or AppCompatActivity).
 * Dependency: implementation("androidx.biometric:biometric:1.1.0")
 */
@Composable
fun AppLockGate(enabled: Boolean, content: @Composable () -> Unit) {
    val activity = LocalContext.current as? FragmentActivity
    var unlocked by remember(enabled) { mutableStateOf(!enabled) }

    if (activity != null) {
        DisposableEffect(enabled) {
            val obs = object : DefaultLifecycleObserver {
                override fun onStop(owner: LifecycleOwner) { if (enabled) unlocked = false }
            }
            activity.lifecycle.addObserver(obs)
            onDispose { activity.lifecycle.removeObserver(obs) }
        }
    }

    if (unlocked || activity == null) {
        content()
        return
    }

    fun prompt() {
        val executor = ContextCompat.getMainExecutor(activity)
        val bp = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                unlocked = true
            }
        })
        bp.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Glasgram")
                .setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)
                .build()
        )
    }

    LaunchedEffect(unlocked) { if (!unlocked) prompt() }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Button(onClick = { prompt() }) { Text("Unlock") }
    }
}
