package com.glasgram.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.glasgram.app.data.ChatKind
import com.glasgram.app.data.Msg
import com.glasgram.app.data.TgRepository
import kotlin.math.abs
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(repo: TgRepository, chatId: Long, onBack: () -> Unit) {
    val s = LocalGlas.current
    val a = accent()
    val haptic = rememberHaptic()
    val clipboard = LocalClipboardManager.current
    val chat = repo.chats[chatId]
    val msgs = repo.messages[chatId] ?: emptyList()
    val byId = remember(msgs) { msgs.associateBy { it.id } }
    val readUpTo = repo.readOutbox[chatId] ?: 0L
    val isGroup = chat?.kind == ChatKind.Group || chat?.kind == ChatKind.Channel

    var input by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<Msg?>(null) }
    var editing by remember { mutableStateOf<Msg?>(null) }
    var menuMsg by remember { mutableStateOf<Msg?>(null) }
    var pendingDelete by remember { mutableStateOf<Msg?>(null) }
    var pendingDeleteEveryone by remember { mutableStateOf(false) }
    var showAttach by remember { mutableStateOf(false) }
    var viewerPath by remember { mutableStateOf<String?>(null) }
    var forwardMsg by remember { mutableStateOf<Msg?>(null) }
    var videoFile by remember { mutableIntStateOf(0) }
    var scheduleDialog by remember { mutableStateOf(false) }
    var showScheduled by remember { mutableStateOf(false) }
    var scheduleEpoch by remember { mutableStateOf((System.currentTimeMillis() / 1000L + 3600L).toString()) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recorder = remember { VoiceRecorder(context) }
    var recording by remember { mutableStateOf(false) }
    var recSecs by remember { mutableIntStateOf(0) }
    val startRec: () -> Unit = {
        if (recorder.start()) { recSecs = 0; recording = true }
        else repo.notice = "Voice recording needs Android 10+ and microphone access"
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRec() else repo.notice = "Microphone permission denied"
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Attachments.copyToCache(context, uri) }
            if (r != null) { repo.sendPhoto(chatId, r.first, "", replyTo?.id ?: 0L); replyTo = null }
            else repo.notice = "Could not read that photo"
        }
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Attachments.copyToCache(context, uri) }
            if (r != null) { repo.sendDocument(chatId, r.first, "", replyTo?.id ?: 0L); replyTo = null }
            else repo.notice = "Could not read that file"
        }
    }
    LaunchedEffect(recording) {
        while (recording) { kotlinx.coroutines.delay(1000); recSecs++ }
    }
    DisposableEffect(Unit) { onDispose { recorder.cancel() } }
    val listState = rememberLazyListState()

    DisposableEffect(chatId) {
        repo.openChat(chatId)
        onDispose { repo.closeChat(chatId); VoicePlayer.stop() }
    }

    val newestId = msgs.firstOrNull()?.id
    LaunchedEffect(newestId) {
        if (listState.firstVisibleItemIndex <= 2) listState.animateScrollToItem(0)
    }
    LaunchedEffect(listState, chatId) {
        snapshotFlow {
            (listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0) to listState.layoutInfo.totalItemsCount
        }.collect { (last, total) ->
            if (total > 0 && last >= total - 6) repo.loadOlder(chatId)
        }
    }

    GlassBackground {
        Column(Modifier.fillMaxSize()) {
            // ── top bar ──
            Row(
                Modifier
                    .statusBarsPadding()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(28.dp), boost = 1.3f)
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Avatar(chat?.title ?: "…", chatId, 40.dp, repo.filePath(chat?.photoFileId ?: 0))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        chat?.title ?: "Chat", color = Color.White, fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    val kind = when (chat?.kind) {
                        ChatKind.Group -> "Group"
                        ChatKind.Channel -> "Channel"
                        ChatKind.Secret -> "Secret chat"
                        else -> "Private chat"
                    }
                    Text(
                        if (s.showIds) "$kind · ID $chatId" else kind,
                        color = Muted, fontSize = 12.sp, maxLines = 1
                    )
                }
                Text("◷", color = Color.White, fontSize = 19.sp,
                    modifier = Modifier.clickable { showScheduled = true; repo.loadScheduledMessages(chatId) }.padding(horizontal = 8.dp, vertical = 6.dp))
                if (s.ghostRead) {
                    val unread = (chat?.unread ?: 0) > 0
                    Text(
                        if (unread) "👻 Mark read" else "👻",
                        color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .glass(CircleShape, boost = 2.2f, tint = a)
                            .clickable(enabled = unread) { repo.markReadNow(chatId); haptic() }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }

            // Exact jump to a message opened from Telegram server search.
            LaunchedEffect(repo.jumpTargetMessageId, msgs) {
                val target = repo.jumpTargetMessageId
                if (target != null) {
                    val index = msgs.indexOfFirst { it.id == target }
                    if (index >= 0) {
                        listState.animateScrollToItem(index)
                        repo.jumpTargetMessageId = null
                    }
                }
            }

            // ── messages ──
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(
                    state = listState,
                    reverseLayout = true,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    itemsIndexed(msgs, key = { _, m -> m.id }) { i, m ->
                        val older = msgs.getOrNull(i + 1)
                        Column(Modifier.fillMaxWidth()) {
                            if (older == null || dayKey(older.date) != dayKey(m.date)) {
                                Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        dayLabel(m.date), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier
                                            .glass(CircleShape)
                                            .padding(horizontal = 12.dp, vertical = 5.dp)
                                    )
                                }
                            }
                            if (isGroup && !m.outgoing && !m.senderIsChat) {
                                LaunchedEffect(m.senderId) { repo.requestUser(m.senderId) }
                            }
                            Bubble(
                                m = m,
                                reply = byId[m.replyToId],
                                showName = isGroup && !m.outgoing,
                                name = repo.senderName(m),
                                read = m.outgoing && m.id <= readUpTo,
                                photoPath = repo.filePath(m.photoFileId),
                                voicePath = repo.filePath(m.voiceFileId),
                                onPhoto = { repo.filePath(m.photoFileId)?.let { viewerPath = it } },
                                stickerPath = repo.filePath(m.stickerFileId),
                                videoThumbPath = repo.filePath(m.videoThumbId),
                                onVideo = { videoFile = m.videoFileId },
                                onVoice = {
                                    val p = repo.filePath(m.voiceFileId)
                                    if (p == null) repo.fetchFile(m.voiceFileId)
                                    else if (!VoicePlayer.toggle(m.voiceFileId, p)) repo.notice = "Could not play this voice message"
                                },
                                onReply = { replyTo = it; editing = null },
                                onMenu = { menuMsg = it }
                            )
                        }
                    }
                }
                if (msgs.isEmpty()) {
                    Text("No messages yet", color = Muted, modifier = Modifier.align(Alignment.Center))
                }
            }

            // ── composer ──
            Column(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                val banner = editing ?: replyTo
                if (banner != null) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .glass(RoundedCornerShape(18.dp))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(3.dp).height(30.dp).background(a, CircleShape))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (editing != null) "Editing message" else "Reply to ${repo.senderName(banner)}",
                                color = a, fontSize = 12.sp, fontWeight = FontWeight.Bold
                            )
                            Text(banner.text, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Icon(
                            Icons.Rounded.Close, contentDescription = "Cancel", tint = Muted,
                            modifier = Modifier.size(22.dp).clickable {
                                if (editing != null) input = ""
                                editing = null; replyTo = null
                            }
                        )
                    }
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    Box(
                        Modifier
                            .size(48.dp)
                            .glass(CircleShape)
                            .clickable {
                                if (recording) { recorder.cancel(); recording = false } else showAttach = true
                            },
                        contentAlignment = Alignment.Center
                    ) { Text(if (recording) "✕" else "📎", color = Color.White, fontSize = 18.sp) }
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .weight(1f)
                            .glass(RoundedCornerShape(26.dp), boost = 1.2f)
                            .padding(horizontal = 18.dp, vertical = 13.dp)
                    ) {
                        if (recording) {
                            Text("🔴  Recording  %d:%02d".format(recSecs / 60, recSecs % 60), color = Color.White, fontSize = 16.sp)
                        } else {
                            if (input.isEmpty()) Text("Message", color = Muted, fontSize = 16.sp)
                            BasicTextField(
                                value = input,
                                onValueChange = { input = it },
                                maxLines = 6,
                                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                                cursorBrush = SolidColor(a),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.size(40.dp).glass(CircleShape).clickable(enabled = input.isNotBlank()) { scheduleDialog = true }, contentAlignment = Alignment.Center) {
                        Text("◷", color = if (input.isNotBlank()) Color.White else Muted, fontSize = 20.sp)
                    }
                    Spacer(Modifier.width(6.dp))
                    val hasText = input.isNotBlank()
                    val active = hasText || recording
                    Box(
                        Modifier
                            .size(48.dp)
                            .glass(CircleShape, boost = if (active) 3f else 1f, tint = if (active) a else Color.White)
                            .clickable {
                                when {
                                    recording -> {
                                        val secs = recSecs
                                        recording = false
                                        val f = recorder.stop()
                                        if (f != null && secs >= 1) { repo.sendVoice(chatId, f.absolutePath, secs, replyTo?.id ?: 0L); replyTo = null }
                                        else { f?.delete(); repo.notice = "Voice message too short" }
                                        haptic()
                                    }
                                    hasText -> {
                                        val text = input.trim()
                                        val e = editing
                                        if (e != null) repo.editMessage(chatId, e.id, text)
                                        else repo.sendText(chatId, text, replyTo?.id ?: 0L)
                                        input = ""; editing = null; replyTo = null
                                        haptic()
                                    }
                                    else -> {
                                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRec()
                                        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (active) Icon(
                            Icons.AutoMirrored.Rounded.Send, contentDescription = "Send",
                            tint = Color.White, modifier = Modifier.size(22.dp)
                        ) else Text("🎤", fontSize = 20.sp)
                    }
                }
            }
        }

        if (showAttach) {
            GlassSheet(title = "Send", onDismiss = { showAttach = false }) {
                SheetAction("🖼", "Photo") {
                    showAttach = false
                    pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                SheetAction("📄", "File") { showAttach = false; pickFile.launch(arrayOf("*/*")) }
            }
        }
        viewerPath?.let { PhotoViewer(it) { viewerPath = null } }
        if (videoFile != 0) VideoPlayerDialog(repo, videoFile) { videoFile = 0 }
        val fwd = forwardMsg
        if (fwd != null) {
            GlassSheet(title = "Forward to…", onDismiss = { forwardMsg = null }) {
                repo.chats.values.sortedByDescending { it.lastDate }.take(8).forEach { c ->
                    SheetAction("💬", c.title) {
                        repo.forwardMessage(c.id, chatId, fwd.id)
                        forwardMsg = null
                        repo.notice = "Forwarded to ${c.title}"
                    }
                }
            }
        }

        // ── message actions ──
        val menu = menuMsg
        if (menu != null) {
            GlassSheet(title = menu.text.replace('\n', ' ').take(60), onDismiss = { menuMsg = null }) {
                SheetAction("↩︎", "Reply") { replyTo = menu; editing = null; menuMsg = null }
                SheetAction("↪️", "Forward") { forwardMsg = menu; menuMsg = null }
                Text("QUICK REACTIONS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp))
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("👍", "❤️", "😂", "🔥", "👏", "😮", "🥰", "🎉", "🤔", "👎").forEach { emoji ->
                        Text(emoji, fontSize = 21.sp, modifier = Modifier
                            .clip(CircleShape)
                            .clickable { repo.addReaction(chatId, menu.id, emoji); menuMsg = null }
                            .padding(5.dp))
                    }
                }
                SheetAction("↩", "Remove my 👍 reaction") { repo.removeReaction(chatId, menu.id, "👍"); menuMsg = null }
                SheetAction("📌", "Pin") { repo.pinMessage(chatId, menu.id); menuMsg = null }
                SheetAction("📋", "Copy text") { clipboard.setText(AnnotatedString(menu.text)); menuMsg = null }
                if (menu.outgoing && !menu.deleted) {
                    SheetAction("✏️", "Edit") { editing = menu; replyTo = null; input = menu.text; menuMsg = null }
                }
                if (!menu.deleted) {
                    SheetAction("🗑", "Delete for me", danger = true) {
                        if (s.confirmBeforeDelete) { pendingDelete = menu; pendingDeleteEveryone = false }
                        else repo.deleteMessage(chatId, menu.id, false)
                        menuMsg = null
                    }
                    SheetAction("🗑", "Delete for everyone", danger = true) {
                        if (s.confirmBeforeDelete) { pendingDelete = menu; pendingDeleteEveryone = true }
                        else repo.deleteMessage(chatId, menu.id, true)
                        menuMsg = null
                    }
                }
                if (s.showIds) {
                    Text("Message ID ${menu.id}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
                }
            }
        }
        if (showScheduled) {
            GlassSheet(title = "Scheduled messages", onDismiss = { showScheduled = false }) {
                val scheduled = repo.scheduledByChat[chatId].orEmpty()
                if (scheduled.isEmpty()) Text("No scheduled messages", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(18.dp))
                scheduled.forEach { item ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text(item.text, color = Color.White, fontSize = 14.sp)
                        Text("Message #${item.id}", color = Muted, fontSize = 10.sp)
                        Text("Cancel scheduled message", color = Color(0xFFFF8A8A), fontSize = 12.sp,
                            modifier = Modifier.clickable { repo.cancelScheduledMessage(chatId, item.id) }.padding(vertical = 6.dp))
                    }
                }
                SheetAction("↻", "Refresh") { repo.loadScheduledMessages(chatId) }
                SheetAction("✕", "Close") { showScheduled = false }
            }
        }
        if (scheduleDialog) {
            AlertDialog(
                onDismissRequest = { scheduleDialog = false },
                title = { Text("Schedule message") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Enter the send time as a Unix timestamp (seconds). The time must be in the future.", color = Muted, fontSize = 12.sp)
                        OutlinedTextField(value = scheduleEpoch, onValueChange = { scheduleEpoch = it.filter(Char::isDigit) }, label = { Text("Send at (Unix seconds)") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val at = scheduleEpoch.toLongOrNull()
                        if (at != null && at > System.currentTimeMillis() / 1000L && input.isNotBlank()) {
                            repo.scheduleText(chatId, input.trim(), at.toInt(), replyTo?.id ?: 0L)
                            input = ""; replyTo = null; scheduleDialog = false
                        } else repo.notice = "Enter a valid future Unix timestamp"
                    }) { Text("Schedule") }
                },
                dismissButton = { TextButton(onClick = { scheduleDialog = false }) { Text("Cancel") } }
            )
        }
        pendingDelete?.let { target ->
            GlassSheet(title = if (pendingDeleteEveryone) "Delete for everyone?" else "Delete this message?", onDismiss = { pendingDelete = null }) {
                Text(
                    if (pendingDeleteEveryone) "This asks Telegram to remove the message for all participants, where allowed."
                    else "This removes the message from your chat view.",
                    color = Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                )
                SheetAction("🗑", "Confirm delete", danger = true) {
                    repo.deleteMessage(chatId, target.id, pendingDeleteEveryone)
                    pendingDelete = null
                }
                SheetAction("✕", "Cancel") { pendingDelete = null }
            }
        }
    }
}

@Composable
private fun Bubble(
    m: Msg,
    reply: Msg?,
    showName: Boolean,
    name: String,
    read: Boolean,
    photoPath: String?,
    voicePath: String?,
    onPhoto: () -> Unit,
    stickerPath: String?,
    videoThumbPath: String?,
    onVideo: () -> Unit,
    onVoice: () -> Unit,
    onReply: (Msg) -> Unit,
    onMenu: (Msg) -> Unit
) {
    val s = LocalGlas.current
    val a = accent()
    val haptic = rememberHaptic()
    val r = s.bubbleRadius.dp
    val shape = RoundedCornerShape(
        topStart = r, topEnd = r,
        bottomStart = if (m.outgoing) r else 6.dp,
        bottomEnd = if (m.outgoing) 6.dp else r
    )
    Box(Modifier.fillMaxWidth()) {
        Column(
            Modifier
                .align(if (m.outgoing) Alignment.CenterEnd else Alignment.CenterStart)
                .widthIn(max = 320.dp)
                .glass(shape, boost = if (m.outgoing) 2.4f else 1.1f, tint = if (m.outgoing) a else Color.White)
                .pointerInput(m.id, s.doubleTapReply) {
                    detectTapGestures(
                        onDoubleTap = { if (s.doubleTapReply) { haptic(); onReply(m) } },
                        onLongPress = { haptic(); onMenu(m) }
                    )
                }
                .padding(horizontal = 13.dp, vertical = 8.dp)
        ) {
            if (showName) {
                Text(
                    name, color = Accents[(abs(m.senderId) % Accents.size).toInt()],
                    fontSize = 12.5.sp, fontWeight = FontWeight.Bold, maxLines = 1
                )
            }
            if (m.replyToId != 0L) {
                Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(3.dp).height(26.dp).background(Color.White.copy(alpha = 0.6f), CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        reply?.text?.replace('\n', ' ') ?: "↩︎ Reply",
                        color = Color.White.copy(alpha = 0.7f), fontSize = 12.5.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 240.dp)
                    )
                }
            }
            if (m.photoFileId != 0) {
                val bmp = rememberBitmap(photoPath, 900)
                val ratio = if (m.photoRatio > 0f) m.photoRatio.coerceIn(0.5f, 2f) else 1f
                Box(
                    Modifier
                        .padding(vertical = 4.dp)
                        .widthIn(max = 280.dp)
                        .fillMaxWidth()
                        .aspectRatio(ratio)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .clickable(onClick = onPhoto),
                    contentAlignment = Alignment.Center
                ) {
                    if (bmp != null) {
                        androidx.compose.foundation.Image(
                            bitmap = bmp, contentDescription = "Photo",
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text("📷", fontSize = 28.sp)
                    }
                }
            }
            if (m.voiceFileId != 0) {
                val playing = VoicePlayer.playingId == m.voiceFileId
                var pos by remember { mutableIntStateOf(0) }
                LaunchedEffect(playing) {
                    while (playing) {
                        pos = VoicePlayer.positionMs()
                        kotlinx.coroutines.delay(200)
                    }
                    pos = 0
                }
                val total = (m.voiceSeconds * 1000).coerceAtLeast(1)
                Row(Modifier.padding(vertical = 4.dp).widthIn(min = 200.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)).clickable(onClick = onVoice),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (voicePath == null) "⬇" else if (playing) "⏸" else "▶", color = Color.White, fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        androidx.compose.material3.LinearProgressIndicator(
                            progress = { (pos.toFloat() / total).coerceIn(0f, 1f) },
                            color = Color.White,
                            trackColor = Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(4.dp))
                        val shown = if (playing) pos / 1000 else m.voiceSeconds
                        Text("%d:%02d".format(shown / 60, shown % 60), color = Color.White.copy(alpha = 0.7f), fontSize = 11.5.sp)
                    }
                }
            }
            val stickerBmp = rememberBitmap(if (stickerPath?.endsWith(".webp", ignoreCase = true) == true) stickerPath else null, 512)
            if (stickerBmp != null) {
                androidx.compose.foundation.Image(
                    bitmap = stickerBmp, contentDescription = "Sticker",
                    modifier = Modifier.padding(vertical = 4.dp).size(150.dp)
                )
            }
            if (m.videoFileId != 0) {
                val thumb = rememberBitmap(videoThumbPath, 700)
                val vr = if (m.videoRatio > 0f) m.videoRatio.coerceIn(0.5f, 2f) else 1.77f
                Box(
                    Modifier
                        .padding(vertical = 4.dp)
                        .widthIn(max = 280.dp)
                        .fillMaxWidth()
                        .aspectRatio(vr)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .clickable(onClick = onVideo),
                    contentAlignment = Alignment.Center
                ) {
                    if (thumb != null) {
                        androidx.compose.foundation.Image(
                            bitmap = thumb, contentDescription = "Video",
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Box(
                        Modifier.size(52.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) { Text("▶", color = Color.White, fontSize = 22.sp) }
                    Text(
                        "%d:%02d".format(m.videoSeconds / 60, m.videoSeconds % 60),
                        color = Color.White, fontSize = 11.5.sp,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            val shownText = when {
                m.voiceFileId != 0 -> ""
                m.photoFileId != 0 -> m.text.removePrefix("📷 Photo").removePrefix("📷 ").trim()
                m.videoFileId != 0 -> m.text.removePrefix("🎬 Video").removePrefix("🎬 ").trim()
                stickerBmp != null -> ""
                else -> m.text
            }
            if (shownText.isNotEmpty()) Text(
                shownText,
                color = if (m.deleted) Color.White.copy(alpha = 0.75f) else Color.White,
                fontSize = (16f * s.textScale).sp,
                textDecoration = if (m.deleted) TextDecoration.LineThrough else null
            )
            if (m.deleted) {
                Text("🗑 Deleted — kept by Glasgram", color = Danger, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
            }
            val original = m.originalText
            if (original != null) {
                Text(
                    "Original: " + original.replace('\n', ' ').take(140),
                    color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, fontStyle = FontStyle.Italic
                )
            }
            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                if (m.edited) Text("edited  ", color = Color.White.copy(alpha = 0.55f), fontSize = 10.5.sp)
                Text(formatClock(m.date, s.use24h), color = Color.White.copy(alpha = 0.55f), fontSize = 10.5.sp)
                if (m.outgoing) {
                    Text(
                        when {
                            m.sending -> "  🕓"
                            read -> "  ✓✓"
                            else -> "  ✓"
                        },
                        color = if (read) Color.White else Color.White.copy(alpha = 0.55f),
                        fontSize = 10.5.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
            if (s.showIds) Text("#${m.id}", color = Color.White.copy(alpha = 0.4f), fontSize = 9.sp)
        }
    }
}
