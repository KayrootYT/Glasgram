package com.glasgram.app.ui

import android.media.MediaPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** One voice message plays at a time. Files are Ogg/Opus, which MediaPlayer supports natively. */
object VoicePlayer {
    var playingId by mutableIntStateOf(0)
        private set
    private var mp: MediaPlayer? = null

    /** Returns false if the file could not be played. */
    fun toggle(fileId: Int, path: String): Boolean {
        if (playingId == fileId) {
            stop()
            return true
        }
        stop()
        return try {
            mp = MediaPlayer().apply {
                setDataSource(path)
                setOnCompletionListener { stop() }
                prepare()
                start()
            }
            playingId = fileId
            true
        } catch (e: Exception) {
            stop()
            false
        }
    }

    fun positionMs(): Int = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }
    fun durationMs(): Int = try { mp?.duration ?: 0 } catch (e: Exception) { 0 }

    fun stop() {
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        playingId = 0
    }
}
