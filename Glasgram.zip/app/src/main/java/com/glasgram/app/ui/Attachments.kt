package com.glasgram.app.ui

import android.content.ContentValues
import android.content.Context
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.File

object Attachments {
    /** Copies a picked content:// Uri into app cache so TDLib can read it by path. */
    fun copyToCache(context: Context, uri: Uri): Pair<String, String>? {
        return try {
            var name = "file"
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
            }
            val dir = File(context.cacheDir, "outgoing").apply { mkdirs() }
            val out = File(dir, "${System.currentTimeMillis()}_${name.replace('/', '_')}")
            val input = context.contentResolver.openInputStream(uri) ?: return null
            input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            out.absolutePath to name
        } catch (e: Exception) {
            null
        }
    }

    /** Saves a downloaded photo to Pictures/Glasgram. Needs Android 10+ (no storage permission). */
    fun saveToGallery(context: Context, path: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Glasgram_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Glasgram")
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            context.contentResolver.openOutputStream(uri)?.use { o -> File(path).inputStream().use { it.copyTo(o) } }
            true
        } catch (e: Exception) {
            false
        }
    }
}

/** Records Ogg/Opus voice notes (what Telegram expects). Android 10+ only. */
class VoiceRecorder(private val context: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    fun start(): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        val f = File(context.cacheDir, "voice_${System.currentTimeMillis()}.ogg")
        return try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.OGG)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.OPUS)
            r.setAudioSamplingRate(48000)
            r.setAudioEncodingBitRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            true
        } catch (e: Exception) {
            cancel()
            false
        }
    }

    fun stop(): File? {
        val r = rec ?: return null
        rec = null
        val f = file
        return try {
            r.stop(); r.release(); f
        } catch (e: Exception) {
            try { r.release() } catch (_: Exception) {}
            f?.delete()
            null
        }
    }

    fun cancel() {
        rec?.let { try { it.stop() } catch (_: Exception) {}; try { it.release() } catch (_: Exception) {} }
        rec = null
        file?.delete()
        file = null
    }
}

@Composable
fun PhotoViewer(path: String, onClose: () -> Unit) {
    val context = LocalContext.current
    val bmp = rememberBitmap(path, 2048)
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (bmp != null) {
                Image(
                    bitmap = bmp, contentDescription = "Photo", contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                offset = if (scale == 1f) Offset.Zero else offset + pan
                            }
                        }
                        .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
                )
            }
            Text(
                "✕", color = Color.White, fontSize = 26.sp,
                modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(16.dp).clickable(onClick = onClose)
            )
            Text(
                "Save", color = Color.White, fontSize = 17.sp,
                modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(16.dp).clickable {
                    val ok = Attachments.saveToGallery(context, path)
                    android.widget.Toast.makeText(
                        context, if (ok) "Saved to Pictures/Glasgram" else "Saving needs Android 10+",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            )
        }
    }
}
