package com.glasgram.app.ui

import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.glasgram.app.data.TgRepository

/** Full-screen video player. Downloads the file first, then plays it with the system VideoView. */
@Composable
fun VideoPlayerDialog(repo: TgRepository, fileId: Int, onClose: () -> Unit) {
    val path = repo.filePath(fileId)
    LaunchedEffect(fileId) { if (repo.filePath(fileId) == null) repo.fetchFile(fileId) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (path == null) {
                Text("Downloading video…", color = Color.White, fontSize = 16.sp, modifier = Modifier.align(Alignment.Center))
            } else {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        VideoView(ctx).apply {
                            val controller = MediaController(ctx)
                            controller.setAnchorView(this)
                            setMediaController(controller)
                            setVideoPath(path)
                            setOnPreparedListener { start() }
                        }
                    }
                )
            }
            Text(
                "✕", color = Color.White, fontSize = 26.sp,
                modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(16.dp).clickable(onClick = onClose)
            )
        }
    }
}
