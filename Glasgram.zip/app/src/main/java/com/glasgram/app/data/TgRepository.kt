package com.glasgram.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.glasgram.app.BuildConfig
import com.glasgram.app.data.telegram.TdLibGateway
import org.drinkless.tdlib.TdApi
import java.util.concurrent.ConcurrentHashMap

enum class Stage { Boot, NoCredentials, EngineError, Loading, Phone, Code, Password, Unsupported, Ready }
enum class ChatKind { Private, Group, Channel, Secret }

data class ChatInfo(
    val id: Long,
    val title: String,
    val kind: ChatKind,
    val unread: Int,
    val markedUnread: Boolean,
    val lastText: String,
    val lastDate: Int,
    val lastOutgoing: Boolean,
    val lastMsgId: Long,
    val order: Long,
    val pinned: Boolean,
    val muted: Boolean,
    val notif: TdApi.ChatNotificationSettings?,
    val photoFileId: Int = 0
)

data class MediaDownload(
    val fileId: Int,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val active: Boolean,
    val completed: Boolean,
    val path: String
) {
    val progress: Float
        get() = if (totalBytes > 0L) (downloadedBytes.toFloat() / totalBytes).coerceIn(0f, 1f) else 0f
}

data class Msg(
    val id: Long,
    val chatId: Long,
    val outgoing: Boolean,
    val date: Int,
    val text: String,
    val senderId: Long,
    val senderIsChat: Boolean,
    val replyToId: Long,
    val sending: Boolean,
    val edited: Boolean = false,
    val deleted: Boolean = false,
    val originalText: String? = null,
    val photoFileId: Int = 0,
    val photoRatio: Float = 0f,
    val voiceFileId: Int = 0,
    val voiceSeconds: Int = 0,
    val stickerFileId: Int = 0,
    val videoFileId: Int = 0,
    val videoThumbId: Int = 0,
    val videoSeconds: Int = 0,
    val videoRatio: Float = 0f
)

/**
 * Single source of truth for the UI. Lives for the whole process so that rotating the
 * screen never creates a second TDLib client on the same database.
 */
class TgRepository private constructor(
    private val context: Context,
    val settings: GlasSettings
) {
    var stage by mutableStateOf(Stage.Boot)
        private set
    var status by mutableStateOf("Starting…")
        private set
    var error by mutableStateOf("")
    var notice by mutableStateOf<String?>(null)
    /** Set by a notification tap; the UI opens this chat once logged in. */
    var pendingOpenChat by mutableStateOf<Long?>(null)
    var busy by mutableStateOf(false)
    var me by mutableStateOf<TdApi.User?>(null)
        private set

    val chats = mutableStateMapOf<Long, ChatInfo>()
    val archivedChatIds = mutableStateMapOf<Long, Boolean>()
    val messages = mutableStateMapOf<Long, List<Msg>>()
    val readOutbox = mutableStateMapOf<Long, Long>()
    val userNames = mutableStateMapOf<Long, String>()
    /** fileId -> local path, for avatars and photos that finished downloading. */
    val files = mutableStateMapOf<Int, String>()
    val downloads = mutableStateMapOf<Int, MediaDownload>()
    val globalSearchResults = mutableStateMapOf<Long, List<Msg>>()
    val contacts = mutableStateListOf<TdApi.User>()
    val scheduledByChat = mutableStateMapOf<Long, List<Msg>>()
    var globalSearchBusy by mutableStateOf(false)
    var contactsBusy by mutableStateOf(false)
    var profileBio by mutableStateOf("")
    var jumpTargetMessageId by mutableStateOf<Long?>(null)
    private val requestedFiles = ConcurrentHashMap.newKeySet<Int>()

    @Volatile private var gateway: TdLibGateway? = null
    @Volatile private var foreground = true
    private val lock = Any()
    private val openChats = ConcurrentHashMap.newKeySet<Long>()
    private val busyChats = ConcurrentHashMap.newKeySet<Long>()
    private val endedChats = ConcurrentHashMap.newKeySet<Long>()
    private val selfDeleted = ConcurrentHashMap.newKeySet<Long>()
    private val askedUsers = ConcurrentHashMap.newKeySet<Long>()

    // ───────────────────────── lifecycle ─────────────────────────

    fun start() {
        if (gateway != null) return
        val id = BuildConfig.TELEGRAM_API_ID
        val hash = BuildConfig.TELEGRAM_API_HASH
        if (id <= 0 || hash.isBlank()) {
            stage = Stage.NoCredentials
            status = "Missing app credentials"
            error = "This build has no Telegram API credentials. Add TELEGRAM_API_ID and TELEGRAM_API_HASH as GitHub Actions secrets and rebuild."
            return
        }
        stage = Stage.Loading
        status = "Starting Telegram engine…"
        error = ""
        try {
            gateway = TdLibGateway.create(
                context, id, hash,
                onUpdate = { g, update -> onUpdate(g, update) },
                onError = { message -> onError(message) }
            )
        } catch (e: Throwable) {
            stage = Stage.EngineError
            status = "Engine failed to start"
            error = "Telegram engine could not start (${e.javaClass.simpleName}): ${e.message ?: "no details"}"
        }
    }

    fun retry() {
        gateway = null
        start()
    }

    fun setForeground(value: Boolean) {
        foreground = value
        applyOnline()
    }

    /** "online" is only ever sent when the app is visible AND Always-Offline is off. */
    fun applyOnline() {
        val g = gateway ?: return
        if (stage != Stage.Ready) return
        g.send(TdApi.SetOption("online", TdApi.OptionValueBoolean(foreground && !settings.alwaysOffline)))
    }

    fun logout() {
        gateway?.send(TdApi.LogOut())
    }

    fun updateProfile(firstName: String, lastName: String, bio: String, username: String? = null) {
        val g = gateway ?: run { notice = "Telegram is not connected"; return }
        val first = firstName.trim()
        if (first.isBlank()) { notice = "First name cannot be empty"; return }
        g.send(TdApi.SetName(first, lastName.trim()))
        // Empty bio is meaningful: it clears the existing Telegram bio.
        g.send(TdApi.SetBio(bio.trim()))
        profileBio = bio.trim()
        if (username != null) g.send(TdApi.SetUsername(username.trim().removePrefix("@")))
        notice = "Profile changes submitted to Telegram"
    }

    // ───────────────────────── extended Telegram features ─────────────────────────

    /** Uses TDLib's server-side global message search (not just messages already loaded locally). */
    fun searchGlobalMessages(query: String) {
        val clean = query.trim()
        if (clean.isBlank()) { globalSearchResults.clear(); return }
        globalSearchBusy = true
        val g = gateway ?: run { globalSearchBusy = false; notice = "Telegram is not connected"; return }
        val req = tdFunction("SearchMessages", mapOf("query" to clean, "offset" to "", "limit" to 50))
            ?: run { globalSearchBusy = false; notice = "This TDLib build does not expose global search"; return }
        g.send(req) { result ->
            globalSearchResults.clear()
            if (result is TdApi.Messages) {
                result.messages.map { toMsg(it) }.groupBy { it.chatId }.forEach { (id, list) -> globalSearchResults[id] = list }
            }
            globalSearchBusy = false
        }
    }

    /** Loads a page centered on a server search hit so the chat can scroll to the exact message. */
    fun openMessageResult(chatId: Long, messageId: Long) {
        val g = gateway ?: return
        val req = TdApi.GetChatHistory(chatId, messageId, -20, 50, false)
        g.send(req) { result ->
            if (result is TdApi.Messages) {
                val page = result.messages.map { toMsg(it) }
                messages[chatId] = mergeMsgs(messages[chatId].orEmpty(), page)
                jumpTargetMessageId = messageId
                notice = "Loaded ${page.size} messages around the search result."
            }
        }
    }

    /** Fetch Telegram's actual contact list; this is separate from private chat history. */
    fun syncContacts() {
        val g = gateway ?: return
        contactsBusy = true
        val req = tdFunction("GetContacts") ?: run { contactsBusy = false; notice = "Contact sync is unavailable in this TDLib build"; return }
        g.send(req) { result ->
            contacts.clear()
            if (result.javaClass.simpleName == "Users") {
                val ids: LongArray = runCatching { result.javaClass.getField("userIds").get(result) as LongArray }.getOrNull() ?: LongArray(0)
                ids.forEach { id -> g.send(TdApi.GetUser(id)) { user ->
                    if (user is TdApi.User && contacts.none { it.id == user.id }) {
                        contacts.add(user)
                        user.profilePhoto?.small?.let { requestFile(it) }
                    }
                } }
            }
            contactsBusy = false
        }
    }

    fun openContact(userId: Long, onChatId: (Long) -> Unit) {
        val g = gateway ?: return
        val req = tdFunction("CreatePrivateChat", mapOf("userId" to userId, "force" to false))
            ?: run { notice = "Could not create private chat with this contact"; return }
        g.send(req) { result ->
            if (result is TdApi.Chat) { upsertChat(result); onChatId(result.id) }
            else if (result is TdApi.Error) notice = result.message
        }
    }

    /** Uploads a Telegram profile photo from a local image file. */
    fun uploadProfilePhoto(path: String) {
        val g = gateway ?: return
        val input = TdApi.InputFileLocal(path)
        val photo = tdObject("InputChatPhotoStatic", mapOf("photo" to input))
            ?: run { notice = "Profile photo upload is unavailable in this TDLib build"; return }
        val req = tdFunction("SetProfilePhoto", mapOf("photo" to photo, "isPublic" to false))
            ?: run { notice = "Profile photo upload is unavailable in this TDLib build"; return }
        g.send(req) { result -> notice = if (result is TdApi.Error) "Profile photo failed: ${result.message}" else "Profile photo update submitted" }
    }

    /** Schedules a text message at a Unix timestamp using TDLib scheduling state. */
    fun scheduleText(chatId: Long, text: String, sendAtEpochSeconds: Int, replyTo: Long = 0L) {
        val g = gateway ?: return
        val schedule = tdObject("MessageSchedulingStateSendAtDate", mapOf("sendDate" to sendAtEpochSeconds))
            ?: run { notice = "Scheduled messages are not supported by this TDLib build"; return }
        val options = tdObject("MessageSendOptions", mapOf("schedulingState" to schedule))
            ?: run { notice = "Scheduled messages are not supported by this TDLib build"; return }
        val req = TdApi.SendMessage()
        req.chatId = chatId
        req.inputMessageContent = textContent(text)
        if (replyTo != 0L) { val r = TdApi.InputMessageReplyToMessage(); r.messageId = replyTo; req.replyTo = r }
        runCatching { req.javaClass.getField("options").set(req, options) }
            .onFailure { notice = "Scheduled send is not available in the bundled TDLib API"; return }
        g.send(req) { result -> notice = if (result is TdApi.Error) "Schedule failed: ${result.message}" else "Message scheduled" }
    }

    fun loadScheduledMessages(chatId: Long) {
        val g = gateway ?: return
        val req = tdFunction("GetChatScheduledMessages", mapOf("chatId" to chatId)) ?: return
        g.send(req) { result ->
            if (result is TdApi.Messages) scheduledByChat[chatId] = result.messages.map { toMsg(it) }
        }
    }

    fun cancelScheduledMessage(chatId: Long, messageId: Long) {
        val req = tdFunction("DeleteMessages", mapOf("chatId" to chatId, "messageIds" to longArrayOf(messageId), "revoke" to false)) ?: return
        gateway?.send(req) { loadScheduledMessages(chatId) }
    }

    /** Toggle a reaction off when the same emoji is selected again. */
    fun removeReaction(chatId: Long, messageId: Long, emoji: String) {
        val reaction = TdApi.ReactionTypeEmoji(emoji)
        val req = tdFunction("RemoveMessageReaction", mapOf("chatId" to chatId, "messageId" to messageId, "reactionType" to reaction))
        if (req != null) gateway?.send(req) else addReaction(chatId, messageId, emoji)
    }

    fun openDownloadedFile(fileId: Int) {
        val path = files[fileId] ?: downloads[fileId]?.path.orEmpty()
        if (path.isBlank()) { notice = "File is not downloaded yet"; return }
        runCatching {
            val file = java.io.File(path)
            val uri = androidx.core.content.FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
            val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }.onFailure { notice = "No app can open this file: ${it.message}" }
    }

    fun clearCompletedDownloads() {
        // TDLib owns its media cache. Remove only manager rows; never delete files behind TDLib's back.
        val completed = downloads.values.filter { it.completed }
        completed.forEach { item -> downloads.remove(item.fileId) }
        notice = "Cleared ${completed.size} completed download entries; Telegram media cache was preserved"
    }

    private fun tdFunction(name: String, fields: Map<String, Any> = emptyMap()): TdApi.Function<*>? =
        tdObject(name, fields) as? TdApi.Function<*>

    private fun tdObject(name: String, fields: Map<String, Any> = emptyMap()): Any? = runCatching {
        val cls = Class.forName("org.drinkless.tdlib.TdApi\$${name}")
        val obj = cls.getDeclaredConstructor().newInstance()
        fields.forEach { (field, value) -> cls.getField(field).set(obj, value) }
        obj
    }.getOrNull()

    // ───────────────────────── auth ─────────────────────────

    fun submitPhone(phone: String) {
        busy = true; error = ""
        gateway?.submitPhoneNumber(phone.trim())
    }

    fun submitCode(code: String) {
        busy = true; error = ""
        gateway?.submitCode(code.trim())
    }

    fun submitPassword(password: String) {
        busy = true; error = ""
        gateway?.submitPassword(password)
    }

    private fun onError(message: String) {
        error = message
        notice = message
        busy = false
    }

    private fun onAuth(g: TdLibGateway, s: TdApi.AuthorizationState) {
        busy = false
        when (s) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> { stage = Stage.Loading; status = "Preparing secure session…" }
            is TdApi.AuthorizationStateWaitPhoneNumber -> { stage = Stage.Phone; status = "Enter your Telegram phone number" }
            is TdApi.AuthorizationStateWaitCode -> { stage = Stage.Code; status = "Enter the code Telegram sent you" }
            is TdApi.AuthorizationStateWaitPassword -> { stage = Stage.Password; status = "Two-step verification password" }
            is TdApi.AuthorizationStateReady -> { stage = Stage.Ready; status = "Connected"; error = ""; onReady(g) }
            is TdApi.AuthorizationStateLoggingOut, is TdApi.AuthorizationStateClosing -> { stage = Stage.Loading; status = "Signing out…" }
            is TdApi.AuthorizationStateClosed -> onClosed()
            else -> {
                stage = Stage.Unsupported
                status = "Unsupported login step"
                error = "This login step is not supported yet. Sign in once with the official Telegram app, then try again."
            }
        }
    }

    private fun onClosed() {
        gateway = null
        chats.clear(); messages.clear(); readOutbox.clear(); userNames.clear()
        openChats.clear(); busyChats.clear(); endedChats.clear(); askedUsers.clear()
        files.clear(); requestedFiles.clear()
        me = null
        stage = Stage.Boot
        Thread { start() }.start()
    }

    private fun onReady(g: TdLibGateway) {
        g.send(TdApi.GetMe()) { r ->
            if (r is TdApi.User) {
                me = r
                userNames[r.id] = fullName(r)
                r.profilePhoto?.small?.let { requestFile(it) }
            }
        }
        loadChatList(g, TdApi.ChatListMain(), false)
        loadChatList(g, TdApi.ChatListArchive(), true)
        syncContacts()
        applyOnline()
    }

    private fun loadChatList(g: TdLibGateway, list: TdApi.ChatList, archived: Boolean) {
        g.send(TdApi.GetChats(list, 200)) { r ->
            if (r is TdApi.Chats) {
                r.chatIds.forEach { id ->
                    if (archived) archivedChatIds[id] = true
                    if (!chats.containsKey(id)) {
                        g.send(TdApi.GetChat(id)) { c ->
                            if (c is TdApi.Chat) {
                                upsertChat(c)
                                if (archived) archivedChatIds[id] = true
                            }
                        }
                    }
                }
            }
        }
    }

    // ───────────────────────── updates ─────────────────────────

    private fun onUpdate(g: TdLibGateway, u: TdApi.Object) {
        if (gateway == null) gateway = g
        when (u) {
            is TdApi.UpdateAuthorizationState -> onAuth(g, u.authorizationState)
            is TdApi.UpdateNewChat -> upsertChat(u.chat)
            is TdApi.UpdateChatTitle -> patchChat(u.chatId) { it.copy(title = u.title) }
            is TdApi.UpdateChatLastMessage -> {
                val lm = u.lastMessage
                val p = u.positions.firstOrNull { it.list is TdApi.ChatListMain }
                patchChat(u.chatId) { c ->
                    val base = if (lm != null) {
                        c.copy(lastText = describe(lm.content), lastDate = lm.date, lastOutgoing = lm.isOutgoing, lastMsgId = lm.id)
                    } else {
                        c.copy(lastText = "", lastDate = 0, lastOutgoing = false, lastMsgId = 0L)
                    }
                    base.copy(order = p?.order ?: 0L, pinned = p?.isPinned ?: false)
                }
            }
            is TdApi.UpdateChatPosition -> {
                when (u.position.list) {
                    is TdApi.ChatListMain -> {
                        archivedChatIds.remove(u.chatId)
                        patchChat(u.chatId) { it.copy(order = u.position.order, pinned = u.position.isPinned) }
                    }
                    is TdApi.ChatListArchive -> {
                        archivedChatIds[u.chatId] = true
                        patchChat(u.chatId) { it.copy(order = u.position.order, pinned = u.position.isPinned) }
                    }
                }
            }
            is TdApi.UpdateChatReadInbox -> patchChat(u.chatId) { it.copy(unread = u.unreadCount) }
            is TdApi.UpdateChatReadOutbox -> readOutbox[u.chatId] = u.lastReadOutboxMessageId
            is TdApi.UpdateChatIsMarkedAsUnread -> patchChat(u.chatId) { it.copy(markedUnread = u.isMarkedAsUnread) }
            is TdApi.UpdateChatNotificationSettings -> patchChat(u.chatId) {
                it.copy(muted = u.notificationSettings.muteFor > 0, notif = u.notificationSettings)
            }
            is TdApi.UpdateUser -> {
                userNames[u.user.id] = fullName(u.user)
                if (u.user.id == me?.id) u.user.profilePhoto?.small?.let { requestFile(it) }
            }
            is TdApi.UpdateFile -> {
                val f = u.file
                val local = f.local
                val completed = local.isDownloadingCompleted && local.path.isNotEmpty()
                if (completed) {
                    files[f.id] = local.path
                    requestedFiles.remove(f.id)
                }
                downloads[f.id] = MediaDownload(
                    fileId = f.id,
                    downloadedBytes = local.downloadedSize.coerceAtLeast(0L),
                    totalBytes = f.expectedSize.takeIf { it > 0L } ?: f.size.coerceAtLeast(0L),
                    active = local.isDownloadingActive,
                    completed = completed,
                    path = local.path
                )
            }
            is TdApi.UpdateChatPhoto -> {
                val small = u.photo?.small
                if (small != null) requestFile(small)
                patchChat(u.chatId) { it.copy(photoFileId = small?.id ?: 0) }
            }
            is TdApi.UpdateNewMessage -> {
                val m = toMsg(u.message)
                mutateMessages(m.chatId) { mergeMsgs(it, listOf(m)) }
                if (!m.outgoing && openChats.contains(m.chatId)) markRead(m.chatId)
                maybeNotify(m)
            }
            is TdApi.UpdateMessageSendSucceeded -> {
                val m = toMsg(u.message)
                val oldId = u.oldMessageId
                mutateMessages(m.chatId) { list -> mergeMsgs(list.filter { it.id != oldId }, listOf(m)) }
            }
            is TdApi.UpdateMessageSendFailed -> notice = "A message could not be sent"
            is TdApi.UpdateMessageContent -> {
                val newText = describe(u.newContent)
                val messageId = u.messageId
                mutateMessages(u.chatId) { list ->
                    list.map { m ->
                        if (m.id == messageId && m.text != newText) {
                            m.copy(
                                text = newText,
                                edited = true,
                                originalText = if (settings.keepEdits) (m.originalText ?: m.text) else null
                            )
                        } else m
                    }
                }
                patchChat(u.chatId) { c -> if (c.lastMsgId == messageId) c.copy(lastText = newText) else c }
            }
            is TdApi.UpdateDeleteMessages -> {
                if (!u.fromCache) {
                    val ids = u.messageIds.toSet()
                    val keep = u.isPermanent && settings.keepDeleted
                    mutateMessages(u.chatId) { list ->
                        list.mapNotNull { m ->
                            when {
                                m.id !in ids -> m
                                keep && m.id !in selfDeleted -> m.copy(deleted = true)
                                else -> null
                            }
                        }
                    }
                    selfDeleted.removeAll(ids)
                }
            }
            else -> Unit
        }
    }

    private fun upsertChat(chat: TdApi.Chat) {
        val p = chat.positions.firstOrNull { it.list is TdApi.ChatListMain }
        val lm = chat.lastMessage
        readOutbox[chat.id] = chat.lastReadOutboxMessageId
        chats[chat.id] = ChatInfo(
            id = chat.id,
            title = chat.title,
            kind = kindOf(chat.type),
            unread = chat.unreadCount,
            markedUnread = chat.isMarkedAsUnread,
            lastText = if (lm != null) describe(lm.content) else "",
            lastDate = lm?.date ?: 0,
            lastOutgoing = lm?.isOutgoing ?: false,
            lastMsgId = lm?.id ?: 0L,
            order = p?.order ?: 0L,
            pinned = p?.isPinned ?: false,
            muted = chat.notificationSettings.muteFor > 0,
            notif = chat.notificationSettings,
            photoFileId = chat.photo?.small?.id ?: 0
        )
        chat.photo?.small?.let { requestFile(it) }
    }

    /** Records finished files and starts downloading missing ones (once per file). */
    private fun requestFile(f: TdApi.File) {
        if (f.local.isDownloadingCompleted && f.local.path.isNotEmpty()) {
            files[f.id] = f.local.path
            return
        }
        if (!requestedFiles.add(f.id)) return
        val req = TdApi.DownloadFile()
        req.fileId = f.id
        req.priority = 8
        req.offset = 0
        req.limit = 0
        req.synchronous = false
        gateway?.send(req)
    }

    private fun maybeNotify(m: Msg) {
        if (m.outgoing || foreground || !settings.notifications) return
        val chat = chats[m.chatId] ?: return
        if (chat.muted || openChats.contains(m.chatId)) return
        val preview = if (settings.notifPreview) m.text.ifBlank { "New message" } else "New message"
        val body = if (chat.kind == ChatKind.Private) preview else "${senderName(m)}: $preview"
        com.glasgram.app.notify.Notifier.showMessage(context, m.chatId, chat.title, body)
    }

    /** Text export of every message Glasgram kept after it was deleted. Null if there are none. */
    fun exportDeletedFile(): java.io.File? {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
        val sb = StringBuilder()
        for ((chatId, list) in messages) {
            val title = chats[chatId]?.title ?: chatId.toString()
            for (m in list.filter { it.deleted }.sortedBy { it.date }) {
                sb.append("[").append(title).append("] ").append(senderName(m))
                    .append(" (").append(fmt.format(java.util.Date(m.date.toLong() * 1000L))).append("): ")
                    .append(m.text).append('\n')
            }
        }
        if (sb.isEmpty()) return null
        val dir = java.io.File(context.cacheDir, "exports").apply { mkdirs() }
        val f = java.io.File(dir, "glasgram-deleted-messages.txt")
        f.writeText(sb.toString())
        return f
    }

    /** Deletes temporary upload/update/voice files from app cache. Returns bytes freed. */
    fun clearTempFiles(): Long {
        var freed = 0L
        fun wipe(f: java.io.File) {
            if (f.isDirectory) f.listFiles()?.forEach { wipe(it) }
            else { freed += f.length(); f.delete() }
        }
        listOf("outgoing", "updates", "exports").forEach { wipe(java.io.File(context.cacheDir, it)) }
        context.cacheDir.listFiles { x -> x.name.startsWith("voice_") }?.forEach { wipe(it) }
        return freed
    }

    /** Re-request a file the user explicitly tapped (e.g. a voice message that is still downloading). */
    fun fetchFile(id: Int) {
        if (id == 0) return
        val req = TdApi.DownloadFile()
        req.fileId = id
        req.priority = 16
        req.offset = 0
        req.limit = 0
        req.synchronous = false
        gateway?.send(req)
    }

    fun filePath(id: Int): String? = if (id == 0) null else files[id]

    /** Download manager view, assembled from TDLib file updates and media in loaded chats. */
    fun mediaDownloads(): List<MediaDownload> = downloads.values.sortedWith(
        compareByDescending<MediaDownload> { it.active }
            .thenByDescending { it.completed }
            .thenByDescending { it.downloadedBytes }
    )

    fun cancelFileDownload(fileId: Int) {
        if (fileId <= 0) return
        val req = TdApi.CancelDownloadFile()
        req.fileId = fileId
        req.onlyIfPending = false
        gateway?.send(req)
        requestedFiles.remove(fileId)
    }

    private fun patchChat(id: Long, f: (ChatInfo) -> ChatInfo) {
        synchronized(lock) {
            val cur = chats[id] ?: return
            chats[id] = f(cur)
        }
    }

    private fun mutateMessages(chatId: Long, f: (List<Msg>) -> List<Msg>) {
        synchronized(lock) {
            val cur = messages[chatId] ?: return
            messages[chatId] = f(cur)
        }
    }

    private fun mergeMsgs(old: List<Msg>, add: List<Msg>): List<Msg> {
        val map = LinkedHashMap<Long, Msg>()
        old.forEach { map[it.id] = it }
        for (n in add) {
            val o = map[n.id]
            map[n.id] = if (o != null) {
                n.copy(deleted = o.deleted, originalText = o.originalText ?: n.originalText, edited = n.edited || o.edited)
            } else n
        }
        return map.values.sortedByDescending { it.id }
    }

    private fun toMsg(m: TdApi.Message): Msg {
        val s = m.senderId
        val sid: Long
        val isChat: Boolean
        if (s is TdApi.MessageSenderUser) { sid = s.userId; isChat = false }
        else if (s is TdApi.MessageSenderChat) { sid = s.chatId; isChat = true }
        else { sid = 0L; isChat = false }
        var stickerId = 0
        var videoId = 0
        var videoThumb = 0
        var videoSecs = 0
        var videoRatio = 0f
        var voiceId = 0
        var voiceSecs = 0
        var photoId = 0
        var photoRatio = 0f
        val content = m.content
        if (content is TdApi.MessagePhoto && content.photo.sizes.isNotEmpty()) {
            val sizes = content.photo.sizes
            val pick = sizes.lastOrNull { it.width <= 900 } ?: sizes.first()
            photoId = pick.photo.id
            if (pick.height > 0) photoRatio = pick.width.toFloat() / pick.height.toFloat()
            requestFile(pick.photo)
        }
        if (content is TdApi.MessageSticker) {
            stickerId = content.sticker.sticker.id
            requestFile(content.sticker.sticker)
        }
        if (content is TdApi.MessageVideo) {
            val v = content.video
            videoId = v.video.id
            videoSecs = v.duration
            if (v.height > 0) videoRatio = v.width.toFloat() / v.height.toFloat()
            v.thumbnail?.let { videoThumb = it.file.id; requestFile(it.file) }
        }
        if (content is TdApi.MessageVoiceNote) {
            voiceId = content.voiceNote.voice.id
            voiceSecs = content.voiceNote.duration
            requestFile(content.voiceNote.voice)
        }
        val r = m.replyTo
        val replyId = if (r is TdApi.MessageReplyToMessage) r.messageId else 0L
        return Msg(
            id = m.id,
            chatId = m.chatId,
            outgoing = m.isOutgoing,
            date = m.date,
            text = describe(m.content),
            senderId = sid,
            senderIsChat = isChat,
            replyToId = replyId,
            sending = m.sendingState != null,
            edited = m.editDate > 0,
            photoFileId = photoId,
            photoRatio = photoRatio,
            voiceFileId = voiceId,
            voiceSeconds = voiceSecs,
            stickerFileId = stickerId,
            videoFileId = videoId,
            videoThumbId = videoThumb,
            videoSeconds = videoSecs,
            videoRatio = videoRatio
        )
    }

    // ───────────────────────── queries for UI ─────────────────────────

    fun sortedChats(): List<ChatInfo> =
        chats.values.filter { it.order > 0L && it.id !in archivedChatIds }.sortedByDescending { it.order }

    fun sortedArchivedChats(): List<ChatInfo> =
        chats.values.filter { it.id in archivedChatIds }.sortedByDescending { it.order }

    fun unarchiveChat(chatId: Long) {
        gateway?.send(TdApi.AddChatToList(chatId, TdApi.ChatListMain()))
    }

    fun senderName(m: Msg): String =
        if (m.senderIsChat) chats[m.senderId]?.title ?: "Channel" else userNames[m.senderId] ?: "…"

    fun requestUser(id: Long) {
        if (id == 0L || userNames.containsKey(id) || !askedUsers.add(id)) return
        gateway?.send(TdApi.GetUser(id)) { r -> if (r is TdApi.User) userNames[id] = fullName(r) }
    }

    // ───────────────────────── chat actions ─────────────────────────

    fun openChat(id: Long) {
        openChats.add(id)
        com.glasgram.app.notify.Notifier.cancelChat(context, id)
        gateway?.send(TdApi.OpenChat(id))
        if (!messages.containsKey(id)) {
            messages[id] = emptyList()
            loadHistory(id)
        } else {
            markRead(id)
        }
    }

    fun closeChat(id: Long) {
        openChats.remove(id)
        gateway?.send(TdApi.CloseChat(id))
    }

    private fun loadHistory(chatId: Long) {
        if (!busyChats.add(chatId)) return
        fetchPage(chatId, 0L, 0)
    }

    fun loadOlder(chatId: Long) {
        if (endedChats.contains(chatId) || !busyChats.add(chatId)) return
        val oldest = messages[chatId]?.minOfOrNull { it.id }
        if (oldest == null) { busyChats.remove(chatId); return }
        fetchPage(chatId, oldest, 0)
    }

    private fun fetchPage(chatId: Long, from: Long, attempt: Int) {
        val g = gateway
        if (g == null) { busyChats.remove(chatId); return }
        g.send(TdApi.GetChatHistory(chatId, from, 0, 50, false)) { r ->
            if (r is TdApi.Messages) {
                val list = r.messages.map { toMsg(it) }
                mutateMessages(chatId) { mergeMsgs(it, list) }
                if (list.isEmpty()) {
                    endedChats.add(chatId); busyChats.remove(chatId)
                } else if (list.size < 20 && attempt < 2) {
                    // TDLib may return a short first page while it is still syncing.
                    fetchPage(chatId, list.minOf { it.id }, attempt + 1)
                } else {
                    busyChats.remove(chatId)
                }
                if (from == 0L && openChats.contains(chatId)) markRead(chatId)
            } else {
                busyChats.remove(chatId)
            }
        }
    }

    /** Respects Ghost Mode: when on, nothing is ever reported as read automatically. */
    fun markRead(chatId: Long) {
        if (settings.ghostRead) return
        if ((chats[chatId]?.unread ?: 0) <= 0) return
        markReadNow(chatId)
    }

    /** Explicit "mark as read" (works even in Ghost Mode because the user asked for it). */
    fun markReadNow(chatId: Long) {
        val g = gateway ?: return
        val id = messages[chatId]?.firstOrNull { !it.outgoing && !it.deleted }?.id
            ?: chats[chatId]?.lastMsgId
            ?: return
        if (id == 0L) return
        val req = TdApi.ViewMessages()
        req.chatId = chatId
        req.messageIds = longArrayOf(id)
        req.source = TdApi.MessageSourceChatHistory()
        req.forceRead = true
        g.send(req)
    }

    fun sendText(chatId: Long, text: String, replyTo: Long) {
        val g = gateway ?: return
        val req = TdApi.SendMessage()
        req.chatId = chatId
        req.inputMessageContent = textContent(text)
        if (replyTo != 0L) {
            val r = TdApi.InputMessageReplyToMessage()
            r.messageId = replyTo
            req.replyTo = r
        }
        g.send(req)
    }

    fun editMessage(chatId: Long, messageId: Long, text: String) {
        val g = gateway ?: return
        val req = TdApi.EditMessageText()
        req.chatId = chatId
        req.messageId = messageId
        req.inputMessageContent = textContent(text)
        g.send(req)
    }

    fun deleteMessage(chatId: Long, messageId: Long, forEveryone: Boolean) {
        val g = gateway ?: return
        selfDeleted.add(messageId)
        val req = TdApi.DeleteMessages()
        req.chatId = chatId
        req.messageIds = longArrayOf(messageId)
        req.revoke = forEveryone
        g.send(req)
    }

    fun togglePin(c: ChatInfo) {
        val req = TdApi.ToggleChatIsPinned()
        req.chatList = TdApi.ChatListMain()
        req.chatId = c.id
        req.isPinned = !c.pinned
        gateway?.send(req)
    }

    fun archiveChat(chatId: Long) {
        gateway?.send(TdApi.AddChatToList(chatId, TdApi.ChatListArchive()))
    }

    fun setMuteFor(c: ChatInfo, seconds: Int) {
        val n = c.notif ?: return
        n.useDefaultMuteFor = false
        n.muteFor = seconds.coerceAtLeast(0)
        gateway?.send(TdApi.SetChatNotificationSettings(c.id, n))
    }

    fun toggleMute(c: ChatInfo) {
        setMuteFor(c, if (c.muted) 0 else 366 * 24 * 3600)
    }

    fun toggleMarkedUnread(c: ChatInfo) {
        val req = TdApi.ToggleChatIsMarkedAsUnread()
        req.chatId = c.id
        req.isMarkedAsUnread = !c.markedUnread
        gateway?.send(req)
    }

    private fun captionOf(text: String) = TdApi.FormattedText(text, arrayOf<TdApi.TextEntity>())

    private fun sendContent(chatId: Long, content: TdApi.InputMessageContent, replyTo: Long) {
        val g = gateway ?: return
        val req = TdApi.SendMessage()
        req.chatId = chatId
        req.inputMessageContent = content
        if (replyTo != 0L) {
            val r = TdApi.InputMessageReplyToMessage()
            r.messageId = replyTo
            req.replyTo = r
        }
        g.send(req)
    }

    fun sendPhoto(chatId: Long, path: String, caption: String, replyTo: Long) {
        val c = TdApi.InputMessagePhoto()
        c.photo = TdApi.InputFileLocal(path)
        c.addedStickerFileIds = IntArray(0)
        c.caption = captionOf(caption)
        sendContent(chatId, c, replyTo)
    }

    fun sendDocument(chatId: Long, path: String, caption: String, replyTo: Long) {
        val c = TdApi.InputMessageDocument()
        c.document = TdApi.InputFileLocal(path)
        c.caption = captionOf(caption)
        sendContent(chatId, c, replyTo)
    }

    fun sendVoice(chatId: Long, path: String, seconds: Int, replyTo: Long) {
        val c = TdApi.InputMessageVoiceNote()
        c.voiceNote = TdApi.InputFileLocal(path)
        c.duration = seconds
        c.waveform = ByteArray(0)
        c.caption = captionOf("")
        sendContent(chatId, c, replyTo)
    }

    fun pinMessage(chatId: Long, messageId: Long) {
        val g = gateway ?: return
        val req = TdApi.PinChatMessage()
        req.chatId = chatId
        req.messageId = messageId
        req.disableNotification = false
        req.onlyForSelf = false
        g.send(req)
    }

    fun addReaction(chatId: Long, messageId: Long, emoji: String) {
        val g = gateway ?: return
        val req = TdApi.AddMessageReaction()
        req.chatId = chatId
        req.messageId = messageId
        req.reactionType = TdApi.ReactionTypeEmoji(emoji)
        req.isBig = false
        req.updateRecentReactions = true
        g.send(req)
    }

    fun forwardMessage(toChatId: Long, fromChatId: Long, messageId: Long) {
        val g = gateway ?: return
        val req = TdApi.ForwardMessages()
        req.chatId = toChatId
        req.fromChatId = fromChatId
        req.messageIds = longArrayOf(messageId)
        req.sendCopy = false
        req.removeCaption = false
        g.send(req)
    }

    private fun textContent(text: String): TdApi.InputMessageText {
        val c = TdApi.InputMessageText()
        c.text = TdApi.FormattedText(text, arrayOf<TdApi.TextEntity>())
        return c
    }

    companion object {
        @Volatile private var instance: TgRepository? = null

        fun get(context: Context): TgRepository =
            instance ?: synchronized(this) {
                instance ?: TgRepository(
                    context.applicationContext,
                    GlasSettings(context.applicationContext)
                ).also { instance = it }
            }
    }
}

private fun kindOf(t: TdApi.ChatType): ChatKind = when (t) {
    is TdApi.ChatTypePrivate -> ChatKind.Private
    is TdApi.ChatTypeSecret -> ChatKind.Secret
    is TdApi.ChatTypeBasicGroup -> ChatKind.Group
    is TdApi.ChatTypeSupergroup -> if (t.isChannel) ChatKind.Channel else ChatKind.Group
    else -> ChatKind.Private
}

private fun fullName(u: TdApi.User): String =
    listOf(u.firstName, u.lastName).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "User" }

private fun describe(c: TdApi.MessageContent): String = when (c) {
    is TdApi.MessageText -> c.text.text
    is TdApi.MessagePhoto -> if (c.caption.text.isBlank()) "📷 Photo" else "📷 " + c.caption.text
    is TdApi.MessageVideo -> if (c.caption.text.isBlank()) "🎬 Video" else "🎬 " + c.caption.text
    is TdApi.MessageAnimation -> "GIF"
    is TdApi.MessageVoiceNote -> "🎤 Voice message"
    is TdApi.MessageVideoNote -> "⏺ Video message"
    is TdApi.MessageAudio -> "🎵 " + c.audio.title.ifBlank { "Audio" }
    is TdApi.MessageDocument -> "📄 " + c.document.fileName.ifBlank { "File" }
    is TdApi.MessageSticker -> c.sticker.emoji + " Sticker"
    is TdApi.MessageLocation -> "📍 Location"
    is TdApi.MessageContact -> "👤 Contact"
    is TdApi.MessagePoll -> "📊 Poll"
    is TdApi.MessageCall -> "📞 Call"
    else -> "Message"
}
