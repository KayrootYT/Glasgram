package com.glasgram.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import android.net.Uri
import java.io.File
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glasgram.app.data.ChatInfo
import com.glasgram.app.data.ChatKind
import com.glasgram.app.data.TgRepository

@Composable
fun ProfileScreen(repo: TgRepository, onOpenSettings: () -> Unit) {
    val me = repo.me
    val name = listOfNotNull(me?.firstName, me?.lastName).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Your profile" }
    val photo = repo.filePath(me?.profilePhoto?.small?.id ?: 0)
    val bio = me?.let { "@${it.usernames?.editableUsername.orEmpty()}" }?.takeIf { it != "@" } ?: "Your Telegram profile"
    var editOpen by remember { mutableStateOf(false) }
    var firstName by remember(me?.firstName) { mutableStateOf(me?.firstName.orEmpty()) }
    var lastName by remember(me?.lastName) { mutableStateOf(me?.lastName.orEmpty()) }
    var about by remember(repo.profileBio) { mutableStateOf(repo.profileBio) }
    var username by remember(me?.usernames?.editableUsername) { mutableStateOf(me?.usernames?.editableUsername.orEmpty()) }
    val context = LocalContext.current
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) runCatching {
            val target = File(context.cacheDir, "profile_upload_${System.currentTimeMillis()}.jpg")
            val input = context.contentResolver.openInputStream(uri) ?: error("Cannot open selected image")
            input.use { stream -> target.outputStream().use { output -> stream.copyTo(output) } }
            require(target.length() > 0L) { "Selected image is empty" }
            repo.uploadProfilePhoto(target.absolutePath)
        }.onFailure { repo.notice = "Could not read selected photo: ${it.message}" }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Profile", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            GlassCircleButton(onClick = onOpenSettings) { Icon(Icons.Rounded.Settings, null, tint = Color.White) }
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(16.dp))
            Avatar(name, me?.id ?: 0L, 104.dp, photo)
            Spacer(Modifier.height(14.dp))
            Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                me?.usernames?.editableUsername?.takeIf { it.isNotBlank() }?.let { "@$it" } ?: "Telegram account",
                color = Muted, fontSize = 13.sp
            )
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProfileAction("📷", "Set Photo", Modifier.weight(1f)) { photoPicker.launch("image/*") }
                ProfileAction("✎", "Edit Info", Modifier.weight(1f)) { editOpen = true }
                ProfileAction("⚙", "Settings", Modifier.weight(1f), onOpenSettings)
            }
            Spacer(Modifier.height(16.dp))
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(18.dp)) {
                ProfileInfo("Phone", me?.phoneNumber?.let { "+$it" } ?: "Not available")
                ProfileInfo("Bio", repo.profileBio.takeIf { it.isNotBlank() } ?: "Not set")
                ProfileInfo("Username", me?.usernames?.editableUsername?.takeIf { it.isNotBlank() }?.let { "@$it" } ?: "Not set")
                ProfileInfo("Numeric ID", me?.id?.toString() ?: "—")
            }
            Spacer(Modifier.height(18.dp))
            Text("Posts", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, modifier = Modifier.align(Alignment.Start).padding(8.dp))
            Column(Modifier.fillMaxWidth().height(180.dp).glass(RoundedCornerShape(24.dp)), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("No posts yet…", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Profile posts will appear here when supported", color = Muted, fontSize = 12.sp)
            }
        }
    }
    if (editOpen) {
        AlertDialog(
            onDismissRequest = { editOpen = false },
            title = { Text("Edit Telegram profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(firstName, { firstName = it }, label = { Text("First name") }, singleLine = true)
                    OutlinedTextField(lastName, { lastName = it }, label = { Text("Last name") }, singleLine = true)
                    OutlinedTextField(about, { about = it.take(70) }, label = { Text("Bio") }, minLines = 2)
                    OutlinedTextField(username, { username = it.removePrefix("@").filter { ch -> ch.isLetterOrDigit() || ch == '_' }.take(32) }, label = { Text("Username") }, singleLine = true)
                    Text("Username availability and Telegram rules are checked by Telegram when saving. Leave it blank to remove it.", color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { repo.updateProfile(firstName, lastName, about, username); editOpen = false }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editOpen = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ProfileAction(icon: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    Column(modifier.glass(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = Color.White, fontSize = 21.sp)
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun ProfileInfo(label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(value, color = Color.White, fontSize = 15.sp)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun ContactsScreen(repo: TgRepository, onOpen: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    val contacts = repo.contacts.filter { user ->
        val name = listOf(user.firstName, user.lastName).filter { it.isNotBlank() }.joinToString(" ")
        query.isBlank() || name.contains(query, true) || user.phoneNumber.contains(query, true) || user.usernames?.editableUsername.orEmpty().contains(query.removePrefix("@"), true)
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 16.dp, top = 16.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Contacts", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(if (repo.contactsBusy) "Syncing…" else "↻ Sync", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.glass(CircleShape).clickable { repo.syncContacts() }.padding(horizontal = 13.dp, vertical = 9.dp))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass(RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Search, null, tint = Muted)
            Spacer(Modifier.width(10.dp))
            androidx.compose.foundation.text.BasicTextField(value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp), decorationBox = { inner -> if (query.isEmpty()) Text("Search Telegram contacts", color = Muted); inner() })
        }
        Text("TELEGRAM CONTACTS · ${repo.contacts.size}", color = Muted, fontSize = 11.sp, letterSpacing = 1.4.sp, modifier = Modifier.padding(start = 22.dp, top = 20.dp, bottom = 10.dp))
        if (contacts.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (repo.contactsBusy) "Loading contacts…" else "No Telegram contacts found", color = Muted) }
        } else LazyColumn(contentPadding = PaddingValues(start = 16.dp, top = 4.dp, end = 16.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(contacts, key = { it.id }) { user ->
                val name = listOf(user.firstName, user.lastName).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Telegram user" }
                Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).clickable { repo.openContact(user.id, onOpen) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    val photoId = user.profilePhoto?.small?.id ?: 0
                    Avatar(name, user.id, if (LocalGlas.current.largeAvatars) 58.dp else 48.dp, repo.filePath(photoId))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(user.usernames?.editableUsername?.takeIf { it.isNotBlank() }?.let { "@$it" } ?: user.phoneNumber.takeIf { it.isNotBlank() } ?: "Telegram contact", color = Muted, fontSize = 12.sp)
                    }
                    Text("›", color = Muted, fontSize = 24.sp)
                }
            }
        }
    }
}

@Composable
private fun ContactRow(chat: ChatInfo, photo: String?, largeAvatar: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(chat.title, chat.id, if (largeAvatar) 58.dp else 48.dp, photo)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Private conversation", color = Muted, fontSize = 12.sp)
        }
        Text("›", color = Muted, fontSize = 24.sp)
    }
}
