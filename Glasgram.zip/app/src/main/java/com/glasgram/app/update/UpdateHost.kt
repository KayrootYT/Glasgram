package com.glasgram.app.update

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import com.glasgram.app.ui.Danger
import com.glasgram.app.ui.GlassButton
import com.glasgram.app.ui.GlassSheet
import com.glasgram.app.ui.Muted
import com.glasgram.app.ui.accent
import kotlinx.coroutines.launch

/** Checks GitHub Releases once per launch and offers an in-place update. */
@Composable
fun UpdateHost(currentVersion: String, enabled: Boolean) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var info by remember { mutableStateOf<UpdateInfo?>(null) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(enabled) { if (enabled) info = UpdateChecker.check(currentVersion) }

    val update = info ?: return
    val busy = progress != null

    GlassSheet(title = "Update available", onDismiss = { if (!busy) info = null }) {
        Column(
            Modifier
                .padding(horizontal = 22.dp, vertical = 6.dp)
                .fillMaxWidth()
        ) {
            Text("Glasgram v${update.versionName}", color = Color.White, fontSize = 20.sp)
            Spacer(Modifier.height(8.dp))
            Column(Modifier.height(120.dp).verticalScroll(rememberScrollState())) {
                Text(update.notes.ifBlank { "Bug fixes and improvements." }, color = Muted, fontSize = 14.sp)
            }
            progress?.let {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(progress = { it }, color = accent(), modifier = Modifier.fillMaxWidth())
            }
            error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = Danger, fontSize = 13.sp)
            }
            Spacer(Modifier.height(14.dp))
            GlassButton(if (busy) "Downloading…" else "Update now", enabled = !busy) {
                error = null
                scope.launch {
                    try {
                        progress = 0f
                        val file = ApkInstaller.download(context, update.apkUrl) { progress = it }
                        progress = null
                        if (ApkInstaller.install(context, file)) info = null
                    } catch (e: Exception) {
                        progress = null
                        error = "Download failed. Check your connection and try again."
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            GlassButton("Later", primary = false, enabled = !busy) { info = null }
        }
    }
}
