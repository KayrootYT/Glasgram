# Build fixes from GitHub Actions run 41270569921

The CI log showed Kotlin compilation failures. Applied fixes:

- Parse persisted hidden chat IDs from SharedPreferences strings into Long values.
- Give the TDLib contact ID array an explicit `LongArray` fallback instead of calling `orEmpty()`.
- Remove the unavailable pointer `consume` import/call from the swipe detector.
- Stop reading `bio` directly from `TdApi.User` (the bundled TDLib User type has no such property); display the locally maintained profile bio state instead.
- Use the supported four-edge `PaddingValues` constructor for the contacts list.
- Import Material3 `LinearProgressIndicator`.

The CI failure occurred in `:app:compileDebugKotlin`; API credential validation passed. A fresh Gradle build is still required to discover any subsequent compiler errors.
