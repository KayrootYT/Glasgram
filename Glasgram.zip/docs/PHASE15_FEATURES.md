# Glasgram — extended messaging and privacy implementation

This update adds Telegram-backed implementations for the previously listed unfinished areas:

- Scheduled text messages through TDLib message scheduling options, a scheduled-message list, refresh, and cancel actions.
- Server-side global message search (TDLib `SearchMessages`) alongside local loaded-message search.
- Search-result opening loads a history page around the hit and asks the chat list to scroll to that message.
- Telegram contact synchronization through TDLib `GetContacts` / `GetUser`, separate from the list of chats; tapping a contact creates/opens the private chat.
- Profile photo selection and upload through TDLib `SetProfilePhoto`.
- Expanded reaction picker and a remove-my-reaction action.
- Media manager open-file action, progress, cancel/retry, and clear-completed-list. Clearing manager rows deliberately preserves TDLib's own media cache.
- Existing client-side privacy controls remain available: Ghost Mode, Always Offline, hidden chats, delete/edit guards, notification and presence preferences.

## Compatibility notes

Some TDLib functions/options are resolved by reflection so the app can gracefully report when a bundled TDLib build does not expose an optional API. In particular scheduled-send options, contact retrieval, profile-photo upload, global search, and scheduled-message retrieval depend on the exact bundled TDLib API version and must be exercised in the Android build/device test. Global search and message-jump behavior also depend on the Telegram account's server-side search permissions and message availability.

This file records code implementation, not a claim of successful compilation or live Telegram validation. Build verification remains the next CI step.
