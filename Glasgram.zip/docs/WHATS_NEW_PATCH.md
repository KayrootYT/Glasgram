# Patch notes

Added
- In-app updater (GitHub Releases, glass-style sheet, in-place install)
- App lock (biometric / phone PIN), re-locks when the app goes to background
- "Hide from screenshots & recents" (FLAG_SECURE)
- Settings group "Security & updates"
- Workflow `release-on-tag.yml`: push tag `vX.Y.Z` -> signed APK in GitHub Releases

Required GitHub secrets for the workflow
GLASGRAM_KEYSTORE_BASE64, GLASGRAM_STORE_PASSWORD, GLASGRAM_KEY_ALIAS, GLASGRAM_KEY_PASSWORD,
TELEGRAM_API_ID, TELEGRAM_API_HASH

Notes
- versionCode = workflow run number. If you already published APKs with higher codes, offset it.
- Not compiled or device-tested here; build and test before releasing.
- Same keystore for every release, or in-place updates will be refused.

## Round 2
- Profile photos in chat list, chat header and settings (downloaded via TDLib, cached locally)
- Photo messages shown inside bubbles with captions
- `upstream-watch.yml`: daily check of TDLib (CMakeLists version) and Telegram Android tags;
  opens a review issue with a checklist. Pinned versions live in `upstream/versions.json`.
  It does NOT auto-merge: TDLib's Java API must match its native binaries.

## Round 3
- Message notifications (channel "Messages"), muted chats and the open chat are skipped
- "Show message preview" toggle
- Optional foreground service "Stay connected in background" (keeps TDLib alive when app is closed)
- Notification permission requested on Android 13+
Limits: no FCM push. If Android kills the process, messages only arrive after the app opens again.
Tapping a notification opens the app, not yet the specific chat.

## Round 4
- Tapping a notification opens that exact chat (works from cold start too)
- Voice messages: auto-download, play/pause, progress bar, duration (one plays at a time; stops when you leave the chat)
Not yet: recording/sending voice messages, video, stickers.

## Round 5
- 📎 attach menu: send photo from gallery, send any file (copied to cache, sent via TDLib)
- 🎤 record and send voice messages (Ogg/Opus, Android 10+), tap to start, tap send, ✕ to cancel
- Tap a photo to open full-screen viewer with pinch-zoom and Save (Android 10+)
- Message menu: Forward (to recent chats) and Pin
- Launcher icon + color resources (previously missing)

## Round 6
- Video messages: thumbnail in chat, tap to download and play full-screen (system VideoView)
- Static stickers (.webp) shown as images; animated (.tgs/.webm) still show emoji for now
- Settings > Glasgram > "Data & storage": export deleted messages as .txt (share sheet), clear temporary files
Note: chat-list search already existed, so it was not re-added.

## TurboTel-inspired navigation and profile refresh

- Expanded the main navigation to Chats, Contacts, Settings, and Profile.
- Added a Contacts view backed by the account's existing private/secret chat list, with search and direct conversation opening.
- Added a Profile view using the signed-in TDLib user details and profile photo, with quick navigation to Settings.
- Preserved the existing Telegram/TDLib repository and chat implementation.
- Profile photo and profile editing actions are visual entry points only where the current backend does not expose a matching edit flow; they do not pretend to save changes.
